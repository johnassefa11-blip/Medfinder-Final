-- =============================================================================
-- MedFinder Pharmacy Vendor Dashboard - Supabase / PostgreSQL Schema
-- =============================================================================
-- Target:  PostgreSQL 15+ (Supabase managed)
-- Engine:  Supabase Auth (auth.users) + PostGIS optional extension for geo
-- Author:  MedFinder Engineering
--
-- This script is idempotent: every object is created with `IF NOT EXISTS`
-- where possible, and policies / triggers are guarded with DROP blocks so
-- re-running the file on an existing database will not error out.
--
-- Run order:
--   1. Extensions
--   2. Tables      (pharmacies, medicines, pharmacy_inventory)
--   3. Indexes     (B-tree on FKs + GiST on geo coordinates)
--   4. Triggers    (auto-update last_updated, sync new auth users)
--   5. RLS         (policies locking data to pharmacy owners)
--   6. Views       (denormalized inventory view for the dashboard)
--   7. Seed data   (optional reference medicines for local dev)
-- =============================================================================


-- ---------------------------------------------------------------------------
-- 1. EXTENSIONS
-- ---------------------------------------------------------------------------
-- `pgcrypto` is bundled with Supabase and provides gen_random_uuid().
-- `postgis` is optional: enables true geographic distance queries.
-- The geo index is created with a fallback to btree if PostGIS is missing.
-- ---------------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS pgcrypto;
-- `pg_trgm` is required by the GIN trigram index on medicines.brand_name below.
CREATE EXTENSION IF NOT EXISTS pg_trgm;
-- CREATE EXTENSION IF NOT EXISTS postgis; -- uncomment if your Supabase project has it


-- ---------------------------------------------------------------------------
-- 2. TABLES
-- ---------------------------------------------------------------------------

-- 2.1 pharmacies
--    One row per registered pharmacy. `owner_id` is a foreign key into
--    Supabase's `auth.users` table — the link between a vendor account and
--    the pharmacy they administer.
CREATE TABLE IF NOT EXISTS public.pharmacies (
    id           UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    name         TEXT         NOT NULL CHECK (char_length(name) BETWEEN 2 AND 120),
    owner_id     UUID         NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    phone        TEXT         NOT NULL CHECK (phone ~ '^\+?[0-9]{7,15}$'),
    sub_city     TEXT         NOT NULL,                            -- e.g. "Bole", "Kirkos"
    woreda       TEXT         NOT NULL,                            -- e.g. "Woreda 03"
    latitude     DOUBLE PRECISION CHECK (latitude  BETWEEN -90  AND 90),
    longitude    DOUBLE PRECISION CHECK (longitude BETWEEN -180 AND 180),
    is_verified  BOOLEAN      NOT NULL DEFAULT FALSE,              -- set by admin after KYC
    created_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW(),

    -- A given owner can only own one pharmacy record. If you need multi-pharmacy
    -- accounts, drop this constraint and adjust the dashboard lookup logic.
    CONSTRAINT pharmacies_owner_id_key UNIQUE (owner_id)
);

COMMENT ON TABLE  public.pharmacies IS 'Registered Ethiopian pharmacies. Each row is owned by exactly one auth.users record.';
COMMENT ON COLUMN public.pharmacies.sub_city  IS 'Addis Ababa sub-city or regional town.';
COMMENT ON COLUMN public.pharmacies.woreda    IS 'Woreda / kebele within the sub-city.';
COMMENT ON COLUMN public.pharmacies.is_verified IS 'True once admin verifies business license.';


-- 2.2 medicines
--    Master catalogue. Shared across all pharmacies — never edited by vendors,
--    only referenced by pharmacy_inventory.
CREATE TABLE IF NOT EXISTS public.medicines (
    id            UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    brand_name    TEXT         NOT NULL CHECK (char_length(brand_name) BETWEEN 1 AND 120),
    generic_name  TEXT         NOT NULL CHECK (char_length(generic_name) BETWEEN 1 AND 120),
    category      TEXT         NOT NULL,                            -- e.g. "Antibiotic", "Analgesic"
    manufacturer  TEXT,                                             -- nullable — generics may have none
    created_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE public.medicines IS 'Master medicine catalogue — one row per brand/generic combination.';

-- Prevent duplicate catalogue entries. Brand+generic must be unique.
CREATE UNIQUE INDEX IF NOT EXISTS medicines_brand_generic_unique_idx
    ON public.medicines (LOWER(brand_name), LOWER(generic_name));


-- 2.3 pharmacy_inventory
--    Junction between a pharmacy and a medicine, carrying stock + commercial
--    fields. A pharmacy may have many rows for the same medicine (different
--    batches / expiry dates).
CREATE TABLE IF NOT EXISTS public.pharmacy_inventory (
    id              UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    pharmacy_id     UUID         NOT NULL REFERENCES public.pharmacies(id)    ON DELETE CASCADE,
    medicine_id     UUID         NOT NULL REFERENCES public.medicines(id)     ON DELETE RESTRICT,
    stock_quantity  INTEGER      NOT NULL DEFAULT 0 CHECK (stock_quantity >= 0),
    price_etb       NUMERIC(10,2) NOT NULL CHECK (price_etb >= 0),           -- Ethiopian Birr
    batch_number    TEXT         NOT NULL,
    expiry_date     DATE         NOT NULL,
    is_available    BOOLEAN      NOT NULL DEFAULT TRUE,
    last_updated    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),

    -- A pharmacy should not have two identical batches of the same medicine.
    -- If you want to allow it (e.g. restocking the same batch), drop this.
    CONSTRAINT pharmacy_inventory_unique_batch UNIQUE (pharmacy_id, medicine_id, batch_number)
);

COMMENT ON TABLE  public.pharmacy_inventory IS 'Per-pharmacy stock rows. Multiple batches per medicine are allowed.';
COMMENT ON COLUMN public.pharmacy_inventory.price_etb IS 'Selling price in Ethiopian Birr.';
COMMENT ON COLUMN public.pharmacy_inventory.is_available IS 'Vendor-controlled visibility toggle.';


-- ---------------------------------------------------------------------------
-- 3. INDEXES
-- ---------------------------------------------------------------------------
-- These are the high-traffic access paths the dashboard will hit.
-- ---------------------------------------------------------------------------

-- Foreign-key lookups: every inventory fetch starts with `pharmacy_id = ?`
CREATE INDEX IF NOT EXISTS pharmacy_inventory_pharmacy_id_idx
    ON public.pharmacy_inventory (pharmacy_id);

-- Used when a vendor edits/queries a specific medicine
CREATE INDEX IF NOT EXISTS pharmacy_inventory_medicine_id_idx
    ON public.pharmacy_inventory (medicine_id);

-- Composite for the most common dashboard filter: "give me my inventory, newest first"
CREATE INDEX IF NOT EXISTS pharmacy_inventory_pharmacy_last_updated_idx
    ON public.pharmacy_inventory (pharmacy_id, last_updated DESC);

-- Common filter: "show me items currently available"
CREATE INDEX IF NOT EXISTS pharmacy_inventory_availability_idx
    ON public.pharmacy_inventory (pharmacy_id, is_available);

-- Expiry-based alerts ("expiring within 30 days")
CREATE INDEX IF NOT EXISTS pharmacy_inventory_expiry_idx
    ON public.pharmacy_inventory (pharmacy_id, expiry_date);

-- Catalogue search by brand/generic name (case-insensitive).
-- Requires the `pg_trgm` extension enabled above.
CREATE INDEX IF NOT EXISTS medicines_brand_name_trgm_idx
    ON public.medicines USING gin (LOWER(brand_name) gin_trgm_ops);
-- Fallback if you ever drop pg_trgm:
-- CREATE INDEX IF NOT EXISTS medicines_brand_name_lower_idx
--     ON public.medicines (LOWER(brand_name));

-- Geo index. If PostGIS is enabled, use a proper geography column. Otherwise
-- we use a btree on (latitude, longitude) which is good enough for
-- "shops near me" bounding-box queries in MVP.
CREATE INDEX IF NOT EXISTS pharmacies_lat_lon_idx
    ON public.pharmacies (latitude, longitude);


-- ---------------------------------------------------------------------------
-- 4. TRIGGERS
-- ---------------------------------------------------------------------------

-- 4.1 Auto-bump `last_updated` whenever a row changes.
CREATE OR REPLACE FUNCTION public.set_last_updated()
RETURNS TRIGGER AS $$
BEGIN
    NEW.last_updated = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_pharmacy_inventory_set_last_updated ON public.pharmacy_inventory;
CREATE TRIGGER trg_pharmacy_inventory_set_last_updated
    BEFORE UPDATE ON public.pharmacy_inventory
    FOR EACH ROW
    EXECUTE FUNCTION public.set_last_updated();


-- ---------------------------------------------------------------------------
-- 5. ROW-LEVEL SECURITY
-- ---------------------------------------------------------------------------
-- Lock the data so vendors can only read/write rows belonging to their own
-- pharmacy. Public read access for the medicines catalogue is allowed so
-- vendors can browse it from the dropdown.
-- ---------------------------------------------------------------------------

ALTER TABLE public.pharmacies          ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.medicines           ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pharmacy_inventory  ENABLE ROW LEVEL SECURITY;

-- Drop existing policies (idempotency)
DROP POLICY IF EXISTS pharmacies_select_own       ON public.pharmacies;
DROP POLICY IF EXISTS pharmacies_insert_self      ON public.pharmacies;
DROP POLICY IF EXISTS pharmacies_update_own       ON public.pharmacies;
DROP POLICY IF EXISTS medicines_select_all        ON public.medicines;
DROP POLICY IF EXISTS medicines_insert_auth       ON public.medicines;
DROP POLICY IF EXISTS inventory_select_own       ON public.pharmacy_inventory;
DROP POLICY IF EXISTS inventory_modify_own       ON public.pharmacy_inventory;
DROP POLICY IF EXISTS inventory_delete_own       ON public.pharmacy_inventory;

-- pharmacies: a vendor can read/update their own row only.
CREATE POLICY pharmacies_select_own
    ON public.pharmacies FOR SELECT
    USING (auth.uid() = owner_id);

CREATE POLICY pharmacies_insert_self
    ON public.pharmacies FOR INSERT
    WITH CHECK (auth.uid() = owner_id);

CREATE POLICY pharmacies_update_own
    ON public.pharmacies FOR UPDATE
    USING (auth.uid() = owner_id)
    WITH CHECK (auth.uid() = owner_id);

-- medicines: catalogue is read-public; inserts require auth (so the Add
-- Medicine flow on the dashboard can create a new catalogue entry).
CREATE POLICY medicines_select_all
    ON public.medicines FOR SELECT
    USING (TRUE);

CREATE POLICY medicines_insert_auth
    ON public.medicines FOR INSERT
    WITH CHECK (auth.uid() IS NOT NULL);

-- pharmacy_inventory: only the owner of the parent pharmacy can touch it.
CREATE POLICY inventory_select_own
    ON public.pharmacy_inventory FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM public.pharmacies p
            WHERE p.id = pharmacy_inventory.pharmacy_id
              AND p.owner_id = auth.uid()
        )
    );

CREATE POLICY inventory_modify_own
    ON public.pharmacy_inventory FOR ALL
    USING (
        EXISTS (
            SELECT 1 FROM public.pharmacies p
            WHERE p.id = pharmacy_inventory.pharmacy_id
              AND p.owner_id = auth.uid()
        )
    )
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM public.pharmacies p
            WHERE p.id = pharmacy_inventory.pharmacy_id
              AND p.owner_id = auth.uid()
        )
    );


-- ---------------------------------------------------------------------------
-- 6. VIEWS
-- ---------------------------------------------------------------------------
-- Convenience view joining inventory with medicine + pharmacy info.
-- The dashboard API hits this view instead of writing multi-table joins
-- every request.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_pharmacy_inventory_full AS
SELECT
    inv.id,
    inv.pharmacy_id,
    p.name         AS pharmacy_name,
    inv.medicine_id,
    m.brand_name,
    m.generic_name,
    m.category,
    m.manufacturer,
    inv.stock_quantity,
    inv.price_etb,
    inv.batch_number,
    inv.expiry_date,
    inv.is_available,
    inv.last_updated,
    inv.created_at,
    -- Derived columns used by the dashboard
    (inv.stock_quantity * inv.price_etb) AS stock_value_etb,
    CASE
        WHEN inv.stock_quantity = 0                         THEN 'out_of_stock'
        WHEN inv.stock_quantity <  10                       THEN 'low_stock'
        WHEN inv.expiry_date <  (NOW() + INTERVAL '30 days') THEN 'expiring_soon'
        ELSE                                                    'good'
    END AS stock_status
FROM public.pharmacy_inventory inv
JOIN public.pharmacies p ON p.id = inv.pharmacy_id
JOIN public.medicines  m ON m.id = inv.medicine_id;

COMMENT ON VIEW public.v_pharmacy_inventory_full IS 'Denormalized inventory view used by the vendor dashboard.';


-- ---------------------------------------------------------------------------
-- 7. SEED DATA (LOCAL DEV ONLY)
-- ---------------------------------------------------------------------------
-- Useful for spinning up a local environment. Comment out in production.
-- ---------------------------------------------------------------------------
INSERT INTO public.medicines (brand_name, generic_name, category, manufacturer) VALUES
    ('Paracetamol 500mg', 'Acetaminophen',   'Analgesic',   'Cadila Pharmaceuticals'),
    ('Amoxil 500mg',      'Amoxicillin',     'Antibiotic',  'GSK'),
    ('Coartem',           'Artemether/Lumefantrine', 'Antimalarial', 'Novartis'),
    ('Metformin 500mg',   'Metformin HCl',   'Antidiabetic','Merck'),
    ('Omeprazole 20mg',   'Omeprazole',      'Antacid',     'Dr. Reddys')
ON CONFLICT DO NOTHING;


-- =============================================================================
-- END OF SCHEMA
-- =============================================================================
