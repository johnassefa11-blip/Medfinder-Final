import type { Config } from 'tailwindcss';

/**
 * Tailwind CSS configuration.
 *
 * The dashboard uses a small, opinionated palette:
 *   - emerald-600  primary brand colour
 *   - slate-50/100  page background + surfaces
 *   - amber/rose    severity accents
 *
 * No custom design tokens are required for the MVP. If the team
 * adopts a broader design system, add a `theme.extend.colors.brand`
 * block here.
 */
const config: Config = {
    content: [
        './app/**/*.{ts,tsx}',
        './components/**/*.{ts,tsx}',
        './hooks/**/*.{ts,tsx}',
        './lib/**/*.{ts,tsx}',
    ],
    theme: {
        extend: {
            fontFamily: {
                sans: [
                    'ui-sans-serif',
                    'system-ui',
                    '-apple-system',
                    'Segoe UI',
                    'Roboto',
                    'Helvetica Neue',
                    'Arial',
                    'Noto Sans',
                    'sans-serif',
                ],
            },
        },
    },
    plugins: [],
};

export default config;
