/** Tailwind + Autoprefixer PostCSS pipeline. */
module.exports = {
    plugins: {
        tailwindcss: {},
        autoprefixer: {},
    },
};
