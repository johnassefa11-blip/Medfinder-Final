/**
 * Hand-written Supabase database typings.
 *
 * In a longer-lived project you would run:
 *     npx supabase gen types typescript --project-id <id> > lib/types/database.ts
 * to auto-generate this file. We ship a hand-written version so the project
 * is fully usable on a fresh checkout with no Supabase login required.
 *
 * If you regenerate, make sure the shape still matches the row types below.
 */

export type Json =
    | string
    | number
    | boolean
    | null
    | { [key: string]: Json | undefined }
    | Json[];

export interface Database {
    public: {
        Tables: {
            pharmacies: {
                Row: {
                    id: string;
                    name: string;
                    owner_id: string;
                    phone: string;
                    sub_city: string;
                    woreda: string;
                    latitude: number | null;
                    longitude: number | null;
                    is_verified: boolean;
                    created_at: string;
                };
                Insert: {
                    id?: string;
                    name: string;
                    owner_id: string;
                    phone: string;
                    sub_city: string;
                    woreda: string;
                    latitude?: number | null;
                    longitude?: number | null;
                    is_verified?: boolean;
                    created_at?: string;
                };
                Update: Partial<Database['public']['Tables']['pharmacies']['Insert']>;
                Relationships: [];
            };
            medicines: {
                Row: {
                    id: string;
                    brand_name: string;
                    generic_name: string;
                    category: string;
                    manufacturer: string | null;
                    created_at: string;
                };
                Insert: {
                    id?: string;
                    brand_name: string;
                    generic_name: string;
                    category: string;
                    manufacturer?: string | null;
                    created_at?: string;
                };
                Update: Partial<Database['public']['Tables']['medicines']['Insert']>;
                Relationships: [];
            };
            pharmacy_inventory: {
                Row: {
                    id: string;
                    pharmacy_id: string;
                    medicine_id: string;
                    stock_quantity: number;
                    price_etb: number;
                    batch_number: string;
                    expiry_date: string;
                    is_available: boolean;
                    last_updated: string;
                    created_at: string;
                };
                Insert: {
                    id?: string;
                    pharmacy_id: string;
                    medicine_id: string;
                    stock_quantity?: number;
                    price_etb: number;
                    batch_number: string;
                    expiry_date: string;
                    is_available?: boolean;
                    last_updated?: string;
                    created_at?: string;
                };
                Update: Partial<Database['public']['Tables']['pharmacy_inventory']['Insert']>;
                Relationships: [
                    {
                        foreignKeyName: 'pharmacy_inventory_pharmacy_id_fkey';
                        columns: ['pharmacy_id'];
                        referencedRelation: 'pharmacies';
                        referencedColumns: ['id'];
                    },
                    {
                        foreignKeyName: 'pharmacy_inventory_medicine_id_fkey';
                        columns: ['medicine_id'];
                        referencedRelation: 'medicines';
                        referencedColumns: ['id'];
                    }
                ];
            };
        };
        Views: {
            v_pharmacy_inventory_full: {
                Row: {
                    id: string;
                    pharmacy_id: string;
                    pharmacy_name: string;
                    medicine_id: string;
                    brand_name: string;
                    generic_name: string;
                    category: string;
                    manufacturer: string | null;
                    stock_quantity: number;
                    price_etb: number;
                    batch_number: string;
                    expiry_date: string;
                    is_available: boolean;
                    last_updated: string;
                    created_at: string;
                    stock_value_etb: number;
                    stock_status: 'good' | 'low_stock' | 'out_of_stock' | 'expiring_soon';
                };
            };
        };
        Enums: Record<string, never>;
        Functions: Record<string, never>;
    };
}
