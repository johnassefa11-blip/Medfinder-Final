/**
 * Application-level TypeScript types.
 *
 * These wrap the raw Supabase row types with the shape the dashboard
 * actually consumes (e.g. joined tables, computed fields).
 */

import type { Database } from './database';

/** A pharmacy row from `pharmacies`. */
export type Pharmacy = Database['public']['Tables']['pharmacies']['Row'];

/** A medicine catalogue row from `medicines`. */
export type Medicine = Database['public']['Tables']['medicines']['Row'];

/**
 * One inventory row enriched with the joined `medicines` and `pharmacies`
 * data the dashboard renders. This is the canonical shape returned by
 * the GET /api/vendor/inventory endpoint.
 */
export interface InventoryRow {
    id: string;
    pharmacy_id: string;
    medicine_id: string;
    stock_quantity: number;
    price_etb: number;
    batch_number: string;
    expiry_date: string;
    is_available: boolean;
    last_updated: string;
    created_at: string;
    medicines: Pick<Medicine, 'id' | 'brand_name' | 'generic_name' | 'category' | 'manufacturer'>;
}

/** Aggregated KPI numbers shown on the top of the dashboard. */
export interface DashboardKpis {
    totalMedicinesInStock: number;
    lowStockAlerts: number;
    outOfStockItems: number;
    totalInventoryValueEtb: number;
}

/** Stock status derived from quantity + expiry. */
export type StockStatus = 'good' | 'low_stock' | 'out_of_stock' | 'expiring_soon';

/**
 * Body shape for POST /api/vendor/inventory.
 *
 * The endpoint supports two modes, discriminated by `mode`:
 *  - `'add'`:    create a new inventory row (optionally creating a new
 *                medicine first if `medicine` carries catalogue fields).
 *  - `'update'`: patch an existing inventory row by `id`.
 */
export type InventoryMutationPayload =
    | {
          mode: 'add';
          medicine:
              | { id: string } // link to an existing catalogue entry
              | {
                    brand_name: string;
                    generic_name: string;
                    category: string;
                    manufacturer?: string | null;
                };
          stock_quantity: number;
          price_etb: number;
          batch_number: string;
          expiry_date: string; // ISO date, e.g. "2027-08-31"
          is_available?: boolean;
      }
    | {
          mode: 'update';
          id: string;
          stock_quantity?: number;
          price_etb?: number;
          batch_number?: string;
          expiry_date?: string;
          is_available?: boolean;
      };

/** Standard JSON envelope returned by the API. */
export type ApiResponse<T> =
    | { ok: true; data: T }
    | { ok: false; error: string; details?: unknown };
