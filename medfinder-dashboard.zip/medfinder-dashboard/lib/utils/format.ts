/**
 * Pure formatting + business-logic helpers.
 *
 * No React, no Supabase — just data → displayable string / status.
 * Safe to import from both server and client code.
 */

import type { StockStatus } from '@/lib/types';

/* -------------------------------------------------------------------------- */
/*  Currency                                                                  */
/* -------------------------------------------------------------------------- */

/**
 * Format a number as Ethiopian Birr.
 * Uses `et-BR` locale which renders with the standard grouping
 * separators familiar to local users (e.g. "1,250.00").
 */
export function formatEtb(value: number | string | null | undefined): string {
    const n = typeof value === 'string' ? Number(value) : value ?? 0;
    if (!Number.isFinite(n)) return 'ETB 0.00';
    return new Intl.NumberFormat('en-ET', {
        style: 'currency',
        currency: 'ETB',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    }).format(n);
}

/* -------------------------------------------------------------------------- */
/*  Dates                                                                     */
/* -------------------------------------------------------------------------- */

/**
 * Format an ISO date string as "31 Aug 2027".
 * Returns "—" for invalid / missing input so the UI doesn't blow up on
 * legacy data.
 */
export function formatDate(iso: string | null | undefined): string {
    if (!iso) return '—';
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return '—';
    return d.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
    });
}

/** Number of whole days until `iso` (negative if already in the past). */
export function daysUntil(iso: string | null | undefined): number {
    if (!iso) return Number.POSITIVE_INFINITY;
    const d = new Date(iso).getTime();
    if (Number.isNaN(d)) return Number.POSITIVE_INFINITY;
    return Math.floor((d - Date.now()) / 86_400_000);
}

/* -------------------------------------------------------------------------- */
/*  Stock status                                                              */
/* -------------------------------------------------------------------------- */

/**
 * Stock-status thresholds.
 *
 * Anything >  LOW_STOCK_THRESHOLD  → 'good'
 * Anything <= LOW_STOCK_THRESHOLD and > 0 → 'low_stock'
 * Anything == 0 → 'out_of_stock'
 *
 * If the expiry is within EXPIRING_SOON_DAYS, status becomes
 * 'expiring_soon' regardless of quantity.
 */
export const LOW_STOCK_THRESHOLD = 10;
export const EXPIRING_SOON_DAYS = 30;

export function deriveStockStatus(
    quantity: number,
    expiryDateIso: string | null | undefined
): StockStatus {
    if (quantity <= 0) return 'out_of_stock';
    if (daysUntil(expiryDateIso) <= EXPIRING_SOON_DAYS) return 'expiring_soon';
    if (quantity <= LOW_STOCK_THRESHOLD) return 'low_stock';
    return 'good';
}

/* -------------------------------------------------------------------------- */
/*  Human-readable labels                                                     */
/* -------------------------------------------------------------------------- */

export function stockStatusLabel(status: StockStatus): string {
    switch (status) {
        case 'good':
            return 'Good';
        case 'low_stock':
            return 'Low';
        case 'out_of_stock':
            return 'Out';
        case 'expiring_soon':
            return 'Expiring';
    }
}

/* -------------------------------------------------------------------------- */
/*  KPI aggregation                                                           */
/* -------------------------------------------------------------------------- */

import type { DashboardKpis, InventoryRow } from '@/lib/types';

/**
 * Compute the four dashboard KPIs from an inventory list.
 * Pure function — easy to test.
 */
export function computeKpis(rows: InventoryRow[]): DashboardKpis {
    let totalMedicinesInStock = 0;
    let lowStockAlerts = 0;
    let outOfStockItems = 0;
    let totalInventoryValueEtb = 0;

    for (const row of rows) {
        const status = deriveStockStatus(row.stock_quantity, row.expiry_date);
        if (row.is_available && row.stock_quantity > 0) {
            totalMedicinesInStock += row.stock_quantity;
        }
        if (status === 'low_stock') lowStockAlerts += 1;
        if (status === 'out_of_stock') outOfStockItems += 1;
        totalInventoryValueEtb += row.stock_quantity * Number(row.price_etb);
    }

    return {
        totalMedicinesInStock,
        lowStockAlerts,
        outOfStockItems,
        totalInventoryValueEtb,
    };
}

/* -------------------------------------------------------------------------- */
/*  Misc                                                                      */
/* -------------------------------------------------------------------------- */

/** Generate a short, time-prefixed ID for client-side optimistic lists. */
export function makeLocalId(): string {
    return `local-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

/** `clsx`-style class joiner without pulling a dependency. */
export function cn(...parts: Array<string | false | null | undefined>): string {
    return parts.filter(Boolean).join(' ');
}
