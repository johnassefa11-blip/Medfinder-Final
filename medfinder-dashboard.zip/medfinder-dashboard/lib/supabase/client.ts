/**
 * Browser-side Supabase client.
 *
 * Use this in Client Components (anything marked `"use client"`).
 * It uses the browser's cookie storage to maintain the auth session.
 */

import { createBrowserClient } from '@supabase/ssr';
import type { Database } from '@/lib/types/database';

export function createSupabaseBrowserClient() {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

    if (!supabaseUrl || !supabaseAnonKey) {
        throw new Error(
            '[supabase/client] Missing NEXT_PUBLIC_SUPABASE_URL or NEXT_PUBLIC_SUPABASE_ANON_KEY.'
        );
    }

    return createBrowserClient<Database>(supabaseUrl, supabaseAnonKey);
}
