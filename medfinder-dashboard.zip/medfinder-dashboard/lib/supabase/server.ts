/**
 * Server-side Supabase client.
 *
 * Use this inside Server Components, Route Handlers, and Server Actions.
 * It uses Next.js 15's `cookies()` API to maintain the auth session
 * across requests and respects RLS policies in Supabase.
 *
 * Reference: https://supabase.com/docs/guides/auth/server-side/nextjs
 */

import { cookies } from 'next/headers';
import { createServerClient } from '@supabase/ssr';
import type { Database } from '@/lib/types/database';

export async function createSupabaseServerClient() {
    const cookieStore = await cookies();

    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

    if (!supabaseUrl || !supabaseAnonKey) {
        throw new Error(
            '[supabase/server] Missing NEXT_PUBLIC_SUPABASE_URL or NEXT_PUBLIC_SUPABASE_ANON_KEY. ' +
                'Copy .env.local.example to .env.local and fill in your project credentials.'
        );
    }

    return createServerClient<Database>(supabaseUrl, supabaseAnonKey, {
        cookies: {
            getAll() {
                return cookieStore.getAll();
            },
            setAll(cookiesToSet) {
                try {
                    for (const { name, value, options } of cookiesToSet) {
                        cookieStore.set(name, value, options);
                    }
                } catch {
                    // The `setAll` method is called from a Server Component —
                    // this is fine to ignore if you have middleware refreshing
                    // the session.
                }
            },
        },
    });
}
