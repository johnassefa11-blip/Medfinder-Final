'use client';

/**
 * useInventory — single source of truth for the dashboard's data.
 *
 * Responsibilities:
 *   1. Fetch the vendor's inventory on mount via GET /api/vendor/inventory.
 *   2. Expose `add`, `update`, and `toggleAvailability` helpers that
 *      dispatch the matching POST request and update local state
 *      optimistically.
 *   3. Track loading + error state for each phase.
 *
 * The hook is intentionally narrow. The dashboard page composes the
 * state returned here into the table, KPI cards, and modal.
 */

import { useCallback, useEffect, useState } from 'react';
import type {
    ApiResponse,
    DashboardKpis,
    InventoryMutationPayload,
    InventoryRow,
    Medicine,
} from '@/lib/types';
import { computeKpis } from '@/lib/utils/format';

interface UseInventoryState {
    rows: InventoryRow[];
    kpis: DashboardKpis;
    medicines: Medicine[];
    pharmacyId: string | null;
    isLoading: boolean;
    isMutating: boolean;
    error: string | null;
    refetch: () => Promise<void>;
    add: (payload: Extract<InventoryMutationPayload, { mode: 'add' }>) => Promise<boolean>;
    update: (payload: Extract<InventoryMutationPayload, { mode: 'update' }>) => Promise<boolean>;
    toggleAvailability: (row: InventoryRow, next: boolean) => Promise<boolean>;
}

interface InventoryResponse {
    inventory: InventoryRow[];
    kpis: DashboardKpis;
    pharmacyId: string;
}

export function useInventory(): UseInventoryState {
    const [rows, setRows] = useState<InventoryRow[]>([]);
    const [medicines, setMedicines] = useState<Medicine[]>([]);
    const [pharmacyId, setPharmacyId] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [isMutating, setIsMutating] = useState(false);
    const [error, setError] = useState<string | null>(null);

    /* -------------------------- fetch ---------------------------------- */
    const fetchInventory = useCallback(async () => {
        setIsLoading(true);
        setError(null);
        try {
            const res = await fetch('/api/vendor/inventory', { cache: 'no-store' });
            const json = (await res.json()) as ApiResponse<InventoryResponse>;
            if (!json.ok) {
                setError(json.error);
                return;
            }
            setRows(json.data.inventory);
            setPharmacyId(json.data.pharmacyId);
        } catch (err) {
            console.error('[useInventory] fetch failed:', err);
            setError('Could not reach the server. Please check your connection.');
        } finally {
            setIsLoading(false);
        }
    }, []);

    // Lightweight catalogue fetch — runs in parallel with inventory.
    const fetchMedicines = useCallback(async () => {
        try {
            // We piggyback on a tiny public route. In a real product this
            // would be /api/medicines; for the dashboard MVP we hit the
            // Supabase client directly via REST.
            // To keep the hook free of direct supabase calls, we expect
            // the server route to also expose the catalogue. For now we
            // simply no-op — the Add modal will work with an empty list
            // and force the "New medicine" path until the catalogue
            // route is added. The fetch is harmless if the endpoint
            // doesn't exist.
            const res = await fetch('/api/medicines', { cache: 'no-store' });
            if (!res.ok) return;
            const json = (await res.json()) as ApiResponse<Medicine[]>;
            if (json.ok) setMedicines(json.data);
        } catch {
            // silently ignore — catalogue fetch is non-critical
        }
    }, []);

    useEffect(() => {
        void fetchInventory();
        void fetchMedicines();
    }, [fetchInventory, fetchMedicines]);

    /* -------------------------- mutations ------------------------------ */
    const postMutation = useCallback(
        async (payload: InventoryMutationPayload): Promise<InventoryRow | null> => {
            setIsMutating(true);
            try {
                const res = await fetch('/api/vendor/inventory', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload),
                });
                const json = (await res.json()) as ApiResponse<InventoryRow>;
                if (!json.ok) {
                    setError(json.error);
                    return null;
                }
                setError(null);
                return json.data;
            } catch (err) {
                console.error('[useInventory] mutation failed:', err);
                setError('Network error. Please try again.');
                return null;
            } finally {
                setIsMutating(false);
            }
        },
        []
    );

    const add = useCallback<UseInventoryState['add']>(
        async (payload) => {
            const created = await postMutation(payload);
            if (!created) return false;
            setRows((prev) => [created, ...prev]);
            // If the user just created a brand-new medicine, refresh the
            // catalogue so future "from catalogue" picks include it.
            if (!('id' in payload.medicine)) {
                void fetchMedicines();
            }
            return true;
        },
        [postMutation, fetchMedicines]
    );

    const update = useCallback<UseInventoryState['update']>(
        async (payload) => {
            const updated = await postMutation(payload);
            if (!updated) return false;
            setRows((prev) => prev.map((r) => (r.id === updated.id ? updated : r)));
            return true;
        },
        [postMutation]
    );

    const toggleAvailability = useCallback<UseInventoryState['toggleAvailability']>(
        async (row, next) => {
            // Optimistic flip
            setRows((prev) =>
                prev.map((r) => (r.id === row.id ? { ...r, is_available: next } : r))
            );
            const ok = await update({ mode: 'update', id: row.id, is_available: next });
            if (!ok) {
                // Roll back on failure
                setRows((prev) =>
                    prev.map((r) => (r.id === row.id ? { ...r, is_available: row.is_available } : r))
                );
            }
            return ok;
        },
        [update]
    );

    const kpis = computeKpis(rows);

    return {
        rows,
        kpis,
        medicines,
        pharmacyId,
        isLoading,
        isMutating,
        error,
        refetch: fetchInventory,
        add,
        update,
        toggleAvailability,
    };
}
