'use client';

/**
 * TopBar — page header. Shows the page title, a primary CTA, and a
 * bell / avatar cluster. Kept intentionally simple.
 */

import { Bell, Plus, Search } from 'lucide-react';
import { Button } from '@/components/ui/Button';

interface TopBarProps {
    pharmacyName?: string;
    onAddClick: () => void;
}

export function TopBar({ pharmacyName, onAddClick }: TopBarProps) {
    return (
        <header className="sticky top-0 z-20 flex h-16 items-center justify-between gap-4 border-b border-slate-200 bg-white/80 px-4 backdrop-blur sm:px-6 lg:px-8">
            <div className="min-w-0">
                <p className="truncate text-xs font-medium uppercase tracking-wider text-slate-400">
                    {pharmacyName ?? 'MedFinder'}
                </p>
                <h1 className="truncate text-lg font-semibold text-slate-900">
                    Inventory Dashboard
                </h1>
            </div>

            <div className="hidden flex-1 max-w-md md:block">
                <label className="relative block">
                    <span className="sr-only">Search inventory</span>
                    <Search
                        className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
                        aria-hidden="true"
                    />
                    <input
                        type="search"
                        placeholder="Search medicine, batch, or category…"
                        className="block w-full rounded-lg border border-slate-200 bg-slate-50 py-2 pl-9 pr-3 text-sm text-slate-700 placeholder:text-slate-400 focus:border-emerald-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-200"
                    />
                </label>
            </div>

            <div className="flex items-center gap-2">
                <Button
                    variant="primary"
                    onClick={onAddClick}
                    leftIcon={<Plus className="h-4 w-4" />}
                    className="hidden sm:inline-flex"
                >
                    Add New Batch
                </Button>
                <button
                    type="button"
                    aria-label="Notifications"
                    className="relative rounded-lg p-2 text-slate-500 transition hover:bg-slate-100 hover:text-slate-900"
                >
                    <Bell className="h-5 w-5" />
                    <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-rose-500" />
                </button>
                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-emerald-100 text-sm font-semibold text-emerald-700">
                    AB
                </div>
            </div>
        </header>
    );
}
