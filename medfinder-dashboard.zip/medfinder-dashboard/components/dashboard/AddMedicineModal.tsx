'use client';

/**
 * AddMedicineModal — handles both `add` and `update` flows.
 *
 * The parent decides which mode is active by passing `editing`:
 *   - `editing === null`          → "Add New Batch / Medicine"
 *   - `editing !== null`           → "Edit Inventory Row"
 *
 * Form state is fully controlled. On submit we call `onSubmit` with a
 * pre-shaped `InventoryMutationPayload` and let the parent dispatch
 * the network call. Field-level validation lives here so the modal
 * can show inline errors instantly.
 *
 * Note: no third-party form library — keeping the bundle small for
 * the local Ethiopian network. We use plain `useState` + small
 * validators below.
 */

import { useEffect, useId, useMemo, useState, type FormEvent } from 'react';
import { Plus, Save } from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';
import { Spinner } from '@/components/ui/Spinner';
import type { InventoryMutationPayload, InventoryRow, Medicine } from '@/lib/types';

type Mode = 'add' | 'update';

interface AddMedicineModalProps {
    isOpen: boolean;
    onClose: () => void;
    /** The row being edited, or `null` for the create flow. */
    editing: InventoryRow | null;
    /** Catalogue entries the user can pick from for the existing-medicine path. */
    medicines: Medicine[];
    isSubmitting: boolean;
    onSubmit: (payload: InventoryMutationPayload) => Promise<void> | void;
}

interface FormState {
    mode: 'existing' | 'new';
    medicineId: string;
    brand_name: string;
    generic_name: string;
    category: string;
    manufacturer: string;
    stock_quantity: string;
    price_etb: string;
    batch_number: string;
    expiry_date: string;
    is_available: boolean;
}

const CATEGORY_OPTIONS = [
    'Analgesic',
    'Antibiotic',
    'Antimalarial',
    'Antidiabetic',
    'Antacid',
    'Antihistamine',
    'Antihypertensive',
    'Cardiovascular',
    'Vitamin / Supplement',
    'Other',
];

function initialState(editing: InventoryRow | null): FormState {
    if (editing) {
        return {
            mode: 'existing',
            medicineId: editing.medicine_id,
            brand_name: editing.medicines.brand_name,
            generic_name: editing.medicines.generic_name,
            category: editing.medicines.category,
            manufacturer: editing.medicines.manufacturer ?? '',
            stock_quantity: String(editing.stock_quantity),
            price_etb: String(editing.price_etb),
            batch_number: editing.batch_number,
            expiry_date: editing.expiry_date,
            is_available: editing.is_available,
        };
    }
    return {
        mode: 'existing',
        medicineId: '',
        brand_name: '',
        generic_name: '',
        category: '',
        manufacturer: '',
        stock_quantity: '',
        price_etb: '',
        batch_number: '',
        expiry_date: '',
        is_available: true,
    };
}

export function AddMedicineModal({
    isOpen,
    onClose,
    editing,
    medicines,
    isSubmitting,
    onSubmit,
}: AddMedicineModalProps) {
    const mode: Mode = editing ? 'update' : 'add';
    const [state, setState] = useState<FormState>(() => initialState(editing));
    const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
    const formId = useId();

    // Reset form whenever the modal opens or the editing target changes.
    useEffect(() => {
        if (isOpen) {
            setState(initialState(editing));
            setErrors({});
        }
    }, [isOpen, editing]);

    const heading = useMemo(
        () =>
            mode === 'add'
                ? 'Add New Batch / Medicine'
                : `Edit · ${editing?.medicines.brand_name ?? 'Inventory row'}`,
        [mode, editing]
    );

    /* --------------------------- validation ---------------------------- */
    function validate(): boolean {
        const next: typeof errors = {};
        if (state.mode === 'existing' && !state.medicineId) {
            next.medicineId = 'Please pick a medicine from the catalogue.';
        }
        if (state.mode === 'new') {
            if (!state.brand_name.trim()) next.brand_name = 'Brand name is required.';
            if (!state.generic_name.trim()) next.generic_name = 'Generic name is required.';
            if (!state.category) next.category = 'Category is required.';
        }
        const qty = Number(state.stock_quantity);
        if (state.stock_quantity === '' || Number.isNaN(qty) || qty < 0) {
            next.stock_quantity = 'Stock must be a non-negative number.';
        }
        const price = Number(state.price_etb);
        if (state.price_etb === '' || Number.isNaN(price) || price < 0) {
            next.price_etb = 'Price must be a non-negative number.';
        }
        if (!state.batch_number.trim()) next.batch_number = 'Batch number is required.';
        if (!state.expiry_date) next.expiry_date = 'Expiry date is required.';
        setErrors(next);
        return Object.keys(next).length === 0;
    }

    /* --------------------------- submit -------------------------------- */
    async function handleSubmit(e: FormEvent<HTMLFormElement>) {
        e.preventDefault();
        if (!validate()) return;

        let payload: InventoryMutationPayload;
        if (mode === 'add') {
            payload = {
                mode: 'add',
                medicine:
                    state.mode === 'existing'
                        ? { id: state.medicineId }
                        : {
                              brand_name: state.brand_name.trim(),
                              generic_name: state.generic_name.trim(),
                              category: state.category,
                              manufacturer: state.manufacturer.trim() || null,
                          },
                stock_quantity: Number(state.stock_quantity),
                price_etb: Number(state.price_etb),
                batch_number: state.batch_number.trim(),
                expiry_date: state.expiry_date,
                is_available: state.is_available,
            };
        } else {
            payload = {
                mode: 'update',
                id: editing!.id,
                stock_quantity: Number(state.stock_quantity),
                price_etb: Number(state.price_etb),
                batch_number: state.batch_number.trim(),
                expiry_date: state.expiry_date,
                is_available: state.is_available,
            };
        }
        await onSubmit(payload);
    }

    /* --------------------------- render -------------------------------- */
    return (
        <Modal
            isOpen={isOpen}
            onClose={onClose}
            title={heading}
            description={
                mode === 'add'
                    ? 'Link a new batch to an existing medicine, or register a brand-new product.'
                    : 'Update stock, price, batch, expiry, and visibility.'
            }
            maxWidthClass="max-w-2xl"
        >
            <form id={formId} onSubmit={handleSubmit} className="space-y-5" noValidate>
                {/* ---- medicine selector -------------------------------- */}
                {mode === 'add' && (
                    <fieldset>
                        <legend className="mb-2 text-sm font-semibold text-slate-700">
                            Medicine
                        </legend>
                        <div className="flex gap-2">
                            <SegmentedToggle
                                value={state.mode}
                                onChange={(v) =>
                                    setState((s) => ({ ...s, mode: v as 'existing' | 'new' }))
                                }
                                options={[
                                    { value: 'existing', label: 'From catalogue' },
                                    { value: 'new', label: 'New medicine' },
                                ]}
                            />
                        </div>

                        {state.mode === 'existing' ? (
                            <div className="mt-3">
                                <Select
                                    label="Catalogue"
                                    value={state.medicineId}
                                    onChange={(v) => setState((s) => ({ ...s, medicineId: v }))}
                                    error={errors.medicineId}
                                    placeholder="Select a medicine…"
                                    options={medicines.map((m) => ({
                                        value: m.id,
                                        label: `${m.brand_name} — ${m.generic_name}`,
                                    }))}
                                />
                            </div>
                        ) : (
                            <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
                                <Field
                                    label="Brand name"
                                    value={state.brand_name}
                                    onChange={(v) => setState((s) => ({ ...s, brand_name: v }))}
                                    error={errors.brand_name}
                                    placeholder="e.g. Paracetamol 500mg"
                                />
                                <Field
                                    label="Generic name"
                                    value={state.generic_name}
                                    onChange={(v) => setState((s) => ({ ...s, generic_name: v }))}
                                    error={errors.generic_name}
                                    placeholder="e.g. Acetaminophen"
                                />
                                <Select
                                    label="Category"
                                    value={state.category}
                                    onChange={(v) => setState((s) => ({ ...s, category: v }))}
                                    error={errors.category}
                                    placeholder="Select a category…"
                                    options={CATEGORY_OPTIONS.map((c) => ({
                                        value: c,
                                        label: c,
                                    }))}
                                />
                                <Field
                                    label="Manufacturer (optional)"
                                    value={state.manufacturer}
                                    onChange={(v) => setState((s) => ({ ...s, manufacturer: v }))}
                                    placeholder="e.g. Cadila Pharmaceuticals"
                                />
                            </div>
                        )}
                    </fieldset>
                )}

                {/* ---- stock + price ----------------------------------- */}
                <fieldset>
                    <legend className="mb-2 text-sm font-semibold text-slate-700">
                        Batch details
                    </legend>
                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                        <Field
                            label="Stock quantity"
                            type="number"
                            min={0}
                            value={state.stock_quantity}
                            onChange={(v) => setState((s) => ({ ...s, stock_quantity: v }))}
                            error={errors.stock_quantity}
                            placeholder="e.g. 50"
                        />
                        <Field
                            label="Price (ETB)"
                            type="number"
                            min={0}
                            step="0.01"
                            value={state.price_etb}
                            onChange={(v) => setState((s) => ({ ...s, price_etb: v }))}
                            error={errors.price_etb}
                            placeholder="e.g. 125.00"
                        />
                        <Field
                            label="Batch number"
                            value={state.batch_number}
                            onChange={(v) => setState((s) => ({ ...s, batch_number: v }))}
                            error={errors.batch_number}
                            placeholder="e.g. BTH-2027-018"
                        />
                        <Field
                            label="Expiry date"
                            type="date"
                            value={state.expiry_date}
                            onChange={(v) => setState((s) => ({ ...s, expiry_date: v }))}
                            error={errors.expiry_date}
                        />
                    </div>
                </fieldset>

                {/* ---- availability ------------------------------------ */}
                <label className="flex cursor-pointer items-center gap-3 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5">
                    <input
                        type="checkbox"
                        checked={state.is_available}
                        onChange={(e) =>
                            setState((s) => ({ ...s, is_available: e.target.checked }))
                        }
                        className="h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                    />
                    <span className="text-sm text-slate-700">
                        Visible to customers (mark as available)
                    </span>
                </label>

                {/* ---- actions ----------------------------------------- */}
                <div className="flex flex-col-reverse gap-2 border-t border-slate-100 pt-4 sm:flex-row sm:justify-end">
                    <Button type="button" variant="secondary" onClick={onClose} disabled={isSubmitting}>
                        Cancel
                    </Button>
                    <Button
                        type="submit"
                        variant="primary"
                        isLoading={isSubmitting}
                        leftIcon={mode === 'add' ? <Plus className="h-4 w-4" /> : <Save className="h-4 w-4" />}
                    >
                        {mode === 'add' ? 'Add to inventory' : 'Save changes'}
                    </Button>
                </div>

                {isSubmitting && (
                    <p className="flex items-center justify-end gap-2 text-xs text-slate-500">
                        <Spinner className="h-3 w-3" /> Saving to your pharmacy…
                    </p>
                )}
            </form>
        </Modal>
    );
}

/* -------------------------------------------------------------------------- */
/*  Small form primitives                                                     */
/* -------------------------------------------------------------------------- */

function Field({
    label,
    value,
    onChange,
    type = 'text',
    error,
    placeholder,
    min,
    step,
}: {
    label: string;
    value: string;
    onChange: (v: string) => void;
    type?: 'text' | 'number' | 'date';
    error?: string;
    placeholder?: string;
    min?: number;
    step?: string;
}) {
    return (
        <label className="block">
            <span className="mb-1 block text-xs font-medium text-slate-700">{label}</span>
            <input
                type={type}
                value={value}
                onChange={(e) => onChange(e.target.value)}
                placeholder={placeholder}
                min={min}
                step={step}
                className={[
                    'block w-full rounded-lg border bg-white px-3 py-2 text-sm text-slate-900 shadow-sm transition',
                    'placeholder:text-slate-400',
                    'focus:outline-none focus:ring-2 focus:ring-offset-0',
                    error
                        ? 'border-rose-300 focus:border-rose-500 focus:ring-rose-200'
                        : 'border-slate-200 focus:border-emerald-500 focus:ring-emerald-200',
                ].join(' ')}
            />
            {error && <span className="mt-1 block text-xs text-rose-600">{error}</span>}
        </label>
    );
}

function Select({
    label,
    value,
    onChange,
    error,
    options,
    placeholder,
}: {
    label: string;
    value: string;
    onChange: (v: string) => void;
    error?: string;
    options: Array<{ value: string; label: string }>;
    placeholder?: string;
}) {
    return (
        <label className="block">
            <span className="mb-1 block text-xs font-medium text-slate-700">{label}</span>
            <select
                value={value}
                onChange={(e) => onChange(e.target.value)}
                className={[
                    'block w-full rounded-lg border bg-white px-3 py-2 text-sm text-slate-900 shadow-sm transition',
                    'focus:outline-none focus:ring-2 focus:ring-offset-0',
                    error
                        ? 'border-rose-300 focus:border-rose-500 focus:ring-rose-200'
                        : 'border-slate-200 focus:border-emerald-500 focus:ring-emerald-200',
                ].join(' ')}
            >
                <option value="" disabled>
                    {placeholder ?? 'Select…'}
                </option>
                {options.map((o) => (
                    <option key={o.value} value={o.value}>
                        {o.label}
                    </option>
                ))}
            </select>
            {error && <span className="mt-1 block text-xs text-rose-600">{error}</span>}
        </label>
    );
}

function SegmentedToggle({
    value,
    onChange,
    options,
}: {
    value: string;
    onChange: (v: string) => void;
    options: Array<{ value: string; label: string }>;
}) {
    return (
        <div className="inline-flex rounded-lg bg-slate-100 p-0.5 text-sm">
            {options.map((o) => {
                const active = o.value === value;
                return (
                    <button
                        key={o.value}
                        type="button"
                        onClick={() => onChange(o.value)}
                        className={[
                            'rounded-md px-3 py-1.5 font-medium transition',
                            active
                                ? 'bg-white text-slate-900 shadow-sm'
                                : 'text-slate-500 hover:text-slate-700',
                        ].join(' ')}
                    >
                        {o.label}
                    </button>
                );
            })}
        </div>
    );
}
