'use client';

/**
 * InventoryTable — the heart of the dashboard.
 *
 * Columns:
 *   1. Brand Name + generic underneath
 *   2. Category
 *   3. Stock (StatusBadge colour-coded)
 *   4. Price (ETB)
 *   5. Expiry date (highlighted if within 30 days)
 *   6. Availability toggle
 *
 * Designed mobile-first: on `sm` screens, columns 2/4 hide and the
 * row becomes a compact card. On `md`+ it's a normal table.
 *
 * Mutations:
 *   - Toggling the availability switch fires a POST with `mode: 'update'`
 *     and optimistically flips the local state for instant feedback.
 *   - `onEdit` (optional) opens the same Add modal in edit mode.
 */

import { useState, useTransition } from 'react';
import {
    AlertTriangle,
    Edit3,
    Pill,
} from 'lucide-react';
import { Spinner } from '@/components/ui/Spinner';
import { StatusBadge } from '@/components/dashboard/StatusBadge';
import { cn, daysUntil, formatDate, formatEtb } from '@/lib/utils/format';
import type { InventoryRow } from '@/lib/types';

interface InventoryTableProps {
    rows: InventoryRow[];
    onEdit?: (row: InventoryRow) => void;
    onToggleAvailability: (row: InventoryRow, next: boolean) => Promise<void>;
}

export function InventoryTable({ rows, onEdit, onToggleAvailability }: InventoryTableProps) {
    return (
        <div className="overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-slate-200/70">
            {/* Desktop / tablet table */}
            <div className="hidden md:block">
                <table className="min-w-full divide-y divide-slate-200">
                    <thead className="bg-slate-50">
                        <tr>
                            <Th>Medicine</Th>
                            <Th>Category</Th>
                            <Th>Stock</Th>
                            <Th>Price</Th>
                            <Th>Expiry</Th>
                            <Th className="text-right">Available</Th>
                            <Th className="text-right">Actions</Th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 bg-white">
                        {rows.map((row) => (
                            <TableRow
                                key={row.id}
                                row={row}
                                onEdit={onEdit}
                                onToggleAvailability={onToggleAvailability}
                            />
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Mobile card list */}
            <ul className="divide-y divide-slate-100 md:hidden">
                {rows.map((row) => (
                    <MobileRow
                        key={row.id}
                        row={row}
                        onEdit={onEdit}
                        onToggleAvailability={onToggleAvailability}
                    />
                ))}
            </ul>

            {rows.length === 0 && <EmptyState />}
        </div>
    );
}

/* -------------------------------------------------------------------------- */
/*  Sub-components                                                             */
/* -------------------------------------------------------------------------- */

function Th({
    children,
    className,
}: {
    children: React.ReactNode;
    className?: string;
}) {
    return (
        <th
            scope="col"
            className={cn(
                'px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500',
                className
            )}
        >
            {children}
        </th>
    );
}

function TableRow({
    row,
    onEdit,
    onToggleAvailability,
}: {
    row: InventoryRow;
    onEdit?: (row: InventoryRow) => void;
    onToggleAvailability: (row: InventoryRow, next: boolean) => Promise<void>;
}) {
    return (
        <tr className="transition hover:bg-slate-50/60">
            <td className="px-4 py-3">
                <div className="flex items-start gap-3">
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600">
                        <Pill className="h-4 w-4" />
                    </div>
                    <div className="min-w-0">
                        <p className="truncate text-sm font-semibold text-slate-900">
                            {row.medicines.brand_name}
                        </p>
                        <p className="truncate text-xs text-slate-500">
                            {row.medicines.generic_name}
                            {row.medicines.manufacturer ? ` · ${row.medicines.manufacturer}` : ''}
                        </p>
                    </div>
                </div>
            </td>
            <td className="px-4 py-3 text-sm text-slate-600">{row.medicines.category}</td>
            <td className="px-4 py-3">
                <StatusBadge
                    stockQuantity={row.stock_quantity}
                    expiryDate={row.expiry_date}
                />
            </td>
            <td className="px-4 py-3 text-sm font-medium text-slate-900">
                {formatEtb(row.price_etb)}
            </td>
            <td className="px-4 py-3 text-sm">
                <ExpiryCell expiryDate={row.expiry_date} />
            </td>
            <td className="px-4 py-3 text-right">
                <AvailabilityToggle
                    checked={row.is_available}
                    onChange={(next) => onToggleAvailability(row, next)}
                />
            </td>
            <td className="px-4 py-3 text-right">
                {onEdit && (
                    <button
                        type="button"
                        onClick={() => onEdit(row)}
                        className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs font-medium text-slate-500 transition hover:bg-slate-100 hover:text-slate-900"
                    >
                        <Edit3 className="h-3.5 w-3.5" />
                        Edit
                    </button>
                )}
            </td>
        </tr>
    );
}

function MobileRow({
    row,
    onEdit,
    onToggleAvailability,
}: {
    row: InventoryRow;
    onEdit?: (row: InventoryRow) => void;
    onToggleAvailability: (row: InventoryRow, next: boolean) => Promise<void>;
}) {
    return (
        <li className="flex flex-col gap-3 px-4 py-4">
            <div className="flex items-start justify-between gap-3">
                <div className="flex min-w-0 items-start gap-3">
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600">
                        <Pill className="h-4 w-4" />
                    </div>
                    <div className="min-w-0">
                        <p className="truncate text-sm font-semibold text-slate-900">
                            {row.medicines.brand_name}
                        </p>
                        <p className="truncate text-xs text-slate-500">
                            {row.medicines.generic_name} · {row.medicines.category}
                        </p>
                    </div>
                </div>
                <span className="text-sm font-semibold text-slate-900">
                    {formatEtb(row.price_etb)}
                </span>
            </div>
            <div className="flex items-center justify-between gap-3">
                <StatusBadge
                    stockQuantity={row.stock_quantity}
                    expiryDate={row.expiry_date}
                />
                <ExpiryCell expiryDate={row.expiry_date} compact />
            </div>
            <div className="flex items-center justify-between">
                <AvailabilityToggle
                    checked={row.is_available}
                    onChange={(next) => onToggleAvailability(row, next)}
                />
                {onEdit && (
                    <button
                        type="button"
                        onClick={() => onEdit(row)}
                        className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs font-medium text-slate-500 transition hover:bg-slate-100 hover:text-slate-900"
                    >
                        <Edit3 className="h-3.5 w-3.5" />
                        Edit
                    </button>
                )}
            </div>
        </li>
    );
}

function ExpiryCell({ expiryDate, compact = false }: { expiryDate: string; compact?: boolean }) {
    const days = daysUntil(expiryDate);
    const isExpiring = days <= 30 && days >= 0;
    const isExpired = days < 0;

    return (
        <div className="flex items-center gap-1.5">
            {(isExpiring || isExpired) && (
                <AlertTriangle
                    className={cn(
                        'h-3.5 w-3.5 shrink-0',
                        isExpired ? 'text-rose-500' : 'text-amber-500'
                    )}
                />
            )}
            <span
                className={cn(
                    compact ? 'text-xs' : 'text-sm',
                    isExpired
                        ? 'font-semibold text-rose-600'
                        : isExpiring
                        ? 'font-medium text-amber-700'
                        : 'text-slate-600'
                )}
            >
                {formatDate(expiryDate)}
            </span>
        </div>
    );
}

function AvailabilityToggle({
    checked,
    onChange,
}: {
    checked: boolean;
    onChange: (next: boolean) => void;
}) {
    const [isPending, startTransition] = useTransition();
    const [busy, setBusy] = useState(false);

    const handleClick = () => {
        if (busy || isPending) return;
        setBusy(true);
        startTransition(async () => {
            try {
                await onChange(!checked);
            } finally {
                setBusy(false);
            }
        });
    };

    return (
        <button
            type="button"
            role="switch"
            aria-checked={checked}
            aria-label={checked ? 'Mark as unavailable' : 'Mark as available'}
            onClick={handleClick}
            disabled={busy}
            className={cn(
                'relative inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full transition',
                'focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:ring-offset-2',
                checked ? 'bg-emerald-500' : 'bg-slate-300',
                busy && 'opacity-60'
            )}
        >
            <span
                className={cn(
                    'inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition',
                    checked ? 'translate-x-6' : 'translate-x-1'
                )}
            />
            {busy && (
                <span className="absolute inset-0 flex items-center justify-center">
                    <Spinner className="h-3 w-3 text-white" label="Updating" />
                </span>
            )}
        </button>
    );
}

function EmptyState() {
    return (
        <div className="flex flex-col items-center justify-center px-6 py-16 text-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-slate-100 text-slate-400">
                <Pill className="h-6 w-6" />
            </div>
            <h3 className="mt-4 text-sm font-semibold text-slate-900">No inventory yet</h3>
            <p className="mt-1 max-w-sm text-sm text-slate-500">
                Add your first medicine batch to start tracking stock levels and expiry dates.
            </p>
        </div>
    );
}
