/**
 * KpiCard — the four headline numbers at the top of the dashboard.
 *
 * Each card is intentionally compact (no chart, no sparkline) to keep
 * the first paint fast on slow Ethiopian 3G connections. The accent
 * is driven by a single prop so the call site can colour-code by
 * severity (e.g. red for "Out of Stock").
 */

import { type LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils/format';

export type KpiAccent = 'emerald' | 'amber' | 'rose' | 'sky';

interface KpiCardProps {
    label: string;
    value: string;
    icon: LucideIcon;
    accent?: KpiAccent;
    /** Optional sub-line under the value, e.g. "↑ 12% from last week". */
    hint?: string;
}

const accentMap: Record<KpiAccent, { ring: string; iconBg: string; iconFg: string }> = {
    emerald: {
        ring: 'ring-emerald-100',
        iconBg: 'bg-emerald-50',
        iconFg: 'text-emerald-600',
    },
    amber: {
        ring: 'ring-amber-100',
        iconBg: 'bg-amber-50',
        iconFg: 'text-amber-600',
    },
    rose: {
        ring: 'ring-rose-100',
        iconBg: 'bg-rose-50',
        iconFg: 'text-rose-600',
    },
    sky: {
        ring: 'ring-sky-100',
        iconBg: 'bg-sky-50',
        iconFg: 'text-sky-600',
    },
};

export function KpiCard({
    label,
    value,
    icon: Icon,
    accent = 'emerald',
    hint,
}: KpiCardProps) {
    const colors = accentMap[accent];

    return (
        <div
            className={cn(
                'group relative flex items-center gap-4 rounded-2xl bg-white p-5 shadow-sm ring-1 ring-slate-200/70',
                'transition hover:shadow-md',
                colors.ring
            )}
        >
            <div
                className={cn(
                    'flex h-12 w-12 shrink-0 items-center justify-center rounded-xl',
                    colors.iconBg
                )}
            >
                <Icon className={cn('h-6 w-6', colors.iconFg)} aria-hidden="true" />
            </div>
            <div className="min-w-0 flex-1">
                <p className="truncate text-xs font-medium uppercase tracking-wider text-slate-500">
                    {label}
                </p>
                <p className="mt-0.5 truncate text-2xl font-semibold text-slate-900">{value}</p>
                {hint && <p className="mt-0.5 text-xs text-slate-400">{hint}</p>}
            </div>
        </div>
    );
}
