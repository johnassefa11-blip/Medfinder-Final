/**
 * Sidebar — fixed left navigation. Collapses on small screens.
 *
 * Visual identity: emerald brand mark + clean slate type. Uses Lucide
 * icons exclusively. No external icon font.
 */

'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
    LayoutDashboard,
    Package,
    ClipboardList,
    Truck,
    Settings,
    LogOut,
    HeartPulse,
} from 'lucide-react';
import { cn } from '@/lib/utils/format';

const NAV_ITEMS = [
    { href: '/vendor/dashboard', label: 'Overview', icon: LayoutDashboard },
    { href: '/vendor/inventory', label: 'Inventory', icon: Package },
    { href: '/vendor/orders', label: 'Orders', icon: ClipboardList, disabled: true },
    { href: '/vendor/suppliers', label: 'Suppliers', icon: Truck, disabled: true },
    { href: '/vendor/settings', label: 'Settings', icon: Settings, disabled: true },
];

export function Sidebar() {
    const pathname = usePathname();

    return (
        <aside className="fixed inset-y-0 left-0 z-30 hidden w-60 flex-col border-r border-slate-200 bg-white lg:flex">
            {/* Brand */}
            <div className="flex h-16 items-center gap-2 border-b border-slate-200 px-5">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-600 text-white">
                    <HeartPulse className="h-5 w-5" />
                </div>
                <div className="leading-tight">
                    <p className="text-sm font-semibold text-slate-900">MedFinder</p>
                    <p className="text-[11px] uppercase tracking-wider text-slate-400">
                        Vendor Portal
                    </p>
                </div>
            </div>

            {/* Nav */}
            <nav className="flex-1 space-y-0.5 p-3">
                {NAV_ITEMS.map((item) => {
                    const Icon = item.icon;
                    const active = pathname === item.href || pathname?.startsWith(item.href + '/');
                    return (
                        <Link
                            key={item.href}
                            href={item.disabled ? '#' : item.href}
                            aria-disabled={item.disabled}
                            className={cn(
                                'group flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition',
                                active
                                    ? 'bg-emerald-50 text-emerald-700'
                                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900',
                                item.disabled && 'pointer-events-none opacity-50'
                            )}
                        >
                            <Icon
                                className={cn(
                                    'h-4 w-4 transition',
                                    active ? 'text-emerald-600' : 'text-slate-400 group-hover:text-slate-600'
                                )}
                            />
                            {item.label}
                            {item.disabled && (
                                <span className="ml-auto rounded-full bg-slate-100 px-1.5 py-0.5 text-[10px] font-medium text-slate-500">
                                    Soon
                                </span>
                            )}
                        </Link>
                    );
                })}
            </nav>

            {/* Footer / sign-out (placeholder) */}
            <div className="border-t border-slate-200 p-3">
                <button
                    type="button"
                    className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-slate-600 transition hover:bg-rose-50 hover:text-rose-700"
                >
                    <LogOut className="h-4 w-4" />
                    Sign out
                </button>
            </div>
        </aside>
    );
}
