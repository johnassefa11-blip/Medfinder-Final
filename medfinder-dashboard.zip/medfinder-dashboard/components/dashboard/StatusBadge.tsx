/**
 * StatusBadge — colour-coded pill that summarises a row's stock health.
 *
 *   good           → emerald  (plenty of stock, expiry healthy)
 *   low_stock      → amber    (≤10 units)
 *   out_of_stock   → rose     (zero units)
 *   expiring_soon  → orange   (≤30 days to expiry)
 */

import { cn, deriveStockStatus, stockStatusLabel, type StockStatus } from '@/lib/utils/format';
import type { InventoryRow } from '@/lib/types';

interface StatusBadgeProps {
    stockQuantity: number;
    expiryDate: string;
}

const styleMap: Record<StockStatus, string> = {
    good: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
    low_stock: 'bg-amber-50 text-amber-700 ring-amber-200',
    out_of_stock: 'bg-rose-50 text-rose-700 ring-rose-200',
    expiring_soon: 'bg-orange-50 text-orange-700 ring-orange-200',
};

const dotMap: Record<StockStatus, string> = {
    good: 'bg-emerald-500',
    low_stock: 'bg-amber-500',
    out_of_stock: 'bg-rose-500',
    expiring_soon: 'bg-orange-500',
};

export function StatusBadge({ stockQuantity, expiryDate }: StatusBadgeProps) {
    const status: StockStatus = deriveStockStatus(stockQuantity, expiryDate);

    return (
        <span
            className={cn(
                'inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset',
                styleMap[status]
            )}
        >
            <span className={cn('h-1.5 w-1.5 rounded-full', dotMap[status])} />
            {stockQuantity} · {stockStatusLabel(status)}
        </span>
    );
}

/** Re-export so the table can colour the whole row consistently. */
export function statusAccentForRow(row: InventoryRow): StockStatus {
    return deriveStockStatus(row.stock_quantity, row.expiry_date);
}
