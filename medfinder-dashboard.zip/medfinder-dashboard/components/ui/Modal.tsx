'use client';

/**
 * Modal — accessible overlay dialog.
 *
 * Features:
 *  - Closes on ESC, on backdrop click, and on explicit close.
 *  - Locks background scroll while open.
 *  - Focus is moved to the dialog on open.
 *  - Body content is provided by children — kept dumb and unstyled.
 *
 * This component owns presentation only. Forms and validation live in
 * their own components and are passed in as `children`.
 */

import { useEffect, useRef, type ReactNode } from 'react';
import { X } from 'lucide-react';
import { cn } from '@/lib/utils/format';

interface ModalProps {
    isOpen: boolean;
    onClose: () => void;
    title: string;
    description?: string;
    children: ReactNode;
    /** Tailwind max-width class. Defaults to `max-w-lg`. */
    maxWidthClass?: string;
}

export function Modal({
    isOpen,
    onClose,
    title,
    description,
    children,
    maxWidthClass = 'max-w-lg',
}: ModalProps) {
    const dialogRef = useRef<HTMLDivElement>(null);

    // ESC + body scroll lock
    useEffect(() => {
        if (!isOpen) return;

        const handleKey = (e: KeyboardEvent) => {
            if (e.key === 'Escape') onClose();
        };
        document.addEventListener('keydown', handleKey);
        const previousOverflow = document.body.style.overflow;
        document.body.style.overflow = 'hidden';

        // Focus the dialog on open
        dialogRef.current?.focus();

        return () => {
            document.removeEventListener('keydown', handleKey);
            document.body.style.overflow = previousOverflow;
        };
    }, [isOpen, onClose]);

    if (!isOpen) return null;

    return (
        <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="modal-title"
            className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6"
        >
            {/* Backdrop */}
            <div
                className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
                onClick={onClose}
                aria-hidden="true"
            />

            {/* Panel */}
            <div
                ref={dialogRef}
                tabIndex={-1}
                className={cn(
                    'relative z-10 w-full overflow-hidden rounded-2xl bg-white shadow-2xl ring-1 ring-slate-200',
                    'animate-in fade-in zoom-in-95 duration-200',
                    maxWidthClass
                )}
            >
                {/* Header */}
                <div className="flex items-start justify-between border-b border-slate-100 px-6 py-4">
                    <div>
                        <h2 id="modal-title" className="text-lg font-semibold text-slate-900">
                            {title}
                        </h2>
                        {description && (
                            <p className="mt-0.5 text-sm text-slate-500">{description}</p>
                        )}
                    </div>
                    <button
                        type="button"
                        onClick={onClose}
                        className="rounded-md p-1.5 text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"
                        aria-label="Close dialog"
                    >
                        <X className="h-5 w-5" />
                    </button>
                </div>

                {/* Body */}
                <div className="max-h-[calc(100vh-12rem)] overflow-y-auto px-6 py-5">
                    {children}
                </div>
            </div>
        </div>
    );
}
