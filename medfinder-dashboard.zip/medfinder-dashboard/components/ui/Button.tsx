'use client';

/**
 * Button — primary / secondary / ghost / danger variants.
 *
 * Keep this component dumb. Async loading state is communicated via
 * the `isLoading` prop so the call-site can wire it to a mutation.
 */

import { forwardRef, type ButtonHTMLAttributes, type ReactNode } from 'react';
import { Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils/format';

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger';
type Size = 'sm' | 'md' | 'lg';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
    variant?: Variant;
    size?: Size;
    isLoading?: boolean;
    leftIcon?: ReactNode;
    rightIcon?: ReactNode;
}

const baseClasses =
    'inline-flex items-center justify-center gap-2 rounded-lg font-medium transition ' +
    'focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 ' +
    'disabled:cursor-not-allowed disabled:opacity-60';

const variantClasses: Record<Variant, string> = {
    primary:
        'bg-emerald-600 text-white shadow-sm hover:bg-emerald-700 ' +
        'focus-visible:ring-emerald-500',
    secondary:
        'bg-white text-slate-700 ring-1 ring-inset ring-slate-200 hover:bg-slate-50 ' +
        'focus-visible:ring-slate-400',
    ghost:
        'bg-transparent text-slate-600 hover:bg-slate-100 hover:text-slate-900 ' +
        'focus-visible:ring-slate-400',
    danger:
        'bg-rose-600 text-white shadow-sm hover:bg-rose-700 ' +
        'focus-visible:ring-rose-500',
};

const sizeClasses: Record<Size, string> = {
    sm: 'h-8 px-3 text-sm',
    md: 'h-10 px-4 text-sm',
    lg: 'h-11 px-5 text-base',
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
    {
        variant = 'primary',
        size = 'md',
        isLoading = false,
        leftIcon,
        rightIcon,
        className,
        children,
        disabled,
        ...rest
    },
    ref
) {
    return (
        <button
            ref={ref}
            disabled={disabled || isLoading}
            className={cn(
                baseClasses,
                variantClasses[variant],
                sizeClasses[size],
                className
            )}
            {...rest}
        >
            {isLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
                leftIcon
            )}
            <span>{children}</span>
            {!isLoading && rightIcon}
        </button>
    );
});
