/**
 * Spinner — tiny inline loading indicator.
 * Used inside buttons and table cells to communicate async state
 * without bumping layout.
 */

import { Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils/format';

interface SpinnerProps {
    className?: string;
    label?: string;
}

export function Spinner({ className, label = 'Loading' }: SpinnerProps) {
    return (
        <span role="status" aria-label={label} className="inline-flex items-center">
            <Loader2 className={cn('h-5 w-5 animate-spin text-slate-400', className)} />
            <span className="sr-only">{label}</span>
        </span>
    );
}
