/**
 * Root index — redirects visitors to the vendor dashboard (or login).
 *
 * We don't render a marketing landing page here; this is a focused
 * vendor portal. Marketing pages live in a separate app/route group
 * in the monorepo.
 */

import { redirect } from 'next/navigation';
import { createSupabaseServerClient } from '@/lib/supabase/server';

export default async function HomePage() {
    const supabase = await createSupabaseServerClient();
    const {
        data: { user },
    } = await supabase.auth.getUser();

    if (user) {
        redirect('/vendor/dashboard');
    } else {
        redirect('/login');
    }
}
