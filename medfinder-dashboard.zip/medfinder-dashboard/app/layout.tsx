/**
 * Root layout for the MedFinder Vendor app.
 *
 *  - Sets the default font stack (system fonts, zero network cost).
 *  - Imports global Tailwind styles.
 *  - Wraps the entire app with the Supabase session refresher.
 */

import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
    title: {
        default: 'MedFinder Vendor',
        template: '%s · MedFinder Vendor',
    },
    description: 'Manage your pharmacy inventory in real time.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
    return (
        <html lang="en" className="bg-slate-50">
            <body className="min-h-screen bg-slate-50 font-sans text-slate-900 antialiased">
                {children}
            </body>
        </html>
    );
}
