/**
 * GET /api/medicines
 *
 * Lightweight catalogue endpoint used by the Add Medicine modal
 * to populate the "From catalogue" dropdown. RLS already exposes
 * the catalogue to all authenticated users, so we just need a
 * thin server wrapper for caching headers + shape.
 */

import { NextResponse } from 'next/server';
import { createSupabaseServerClient } from '@/lib/supabase/server';
import type { ApiResponse, Medicine } from '@/lib/types';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
    try {
        const supabase = await createSupabaseServerClient();

        // Verify the user is signed in — vendors only.
        const {
            data: { user },
        } = await supabase.auth.getUser();
        if (!user) {
            return NextResponse.json(
                { ok: false, error: 'Unauthorized' },
                { status: 401 }
            );
        }

        const { data, error } = await supabase
            .from('medicines')
            .select('id, brand_name, generic_name, category, manufacturer, created_at')
            .order('brand_name', { ascending: true })
            .limit(500);

        if (error) {
            console.error('[medicines][GET] supabase error:', error);
            return NextResponse.json(
                { ok: false, error: 'Failed to load medicine catalogue.' },
                { status: 500 }
            );
        }

        const response: ApiResponse<Medicine[]> = {
            ok: true,
            data: (data ?? []) as Medicine[],
        };
        return NextResponse.json(response, {
            status: 200,
            headers: {
                // Catalogue changes infrequently — cache for 5 minutes on
                // the CDN, allow stale-while-revalidate for 1 day.
                'Cache-Control': 'public, s-maxage=300, stale-while-revalidate=86400',
            },
        });
    } catch (err) {
        console.error('[medicines][GET] unexpected error:', err);
        return NextResponse.json(
            { ok: false, error: 'Unexpected server error.' },
            { status: 500 }
        );
    }
}
