/**
 * Minimal login stub.
 *
 *  In production this is a real Supabase auth form. For the MVP
 *  scaffold we keep it deliberately simple so the dashboard route
 *  works end-to-end after `supabase start` without extra code.
 *  Local developers can replace this with the team's preferred
 *  auth UX (email magic link, OTP, OAuth, etc.).
 */

'use client';

import { useState, type FormEvent } from 'react';
import { HeartPulse, Mail } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { createSupabaseBrowserClient } from '@/lib/supabase/client';

export default function LoginPage() {
    const [email, setEmail] = useState('');
    const [isSending, setIsSending] = useState(false);
    const [message, setMessage] = useState<string | null>(null);

    async function handleSubmit(e: FormEvent<HTMLFormElement>) {
        e.preventDefault();
        setIsSending(true);
        setMessage(null);
        try {
            const supabase = createSupabaseBrowserClient();
            const { error } = await supabase.auth.signInWithOtp({
                email,
                options: { emailRedirectTo: `${window.location.origin}/vendor/dashboard` },
            });
            if (error) {
                setMessage(error.message);
            } else {
                setMessage('Check your inbox for the magic link.');
            }
        } finally {
            setIsSending(false);
        }
    }

    return (
        <div className="flex min-h-screen items-center justify-center bg-slate-50 p-6">
            <form
                onSubmit={handleSubmit}
                className="w-full max-w-sm rounded-2xl bg-white p-8 shadow-sm ring-1 ring-slate-200"
            >
                <div className="flex items-center gap-2">
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-600 text-white">
                        <HeartPulse className="h-5 w-5" />
                    </div>
                    <p className="text-base font-semibold text-slate-900">MedFinder Vendor</p>
                </div>
                <h1 className="mt-6 text-xl font-semibold text-slate-900">Sign in</h1>
                <p className="mt-1 text-sm text-slate-500">
                    We'll email you a magic link — no password required.
                </p>

                <label className="mt-6 block">
                    <span className="mb-1 block text-xs font-medium text-slate-700">Email</span>
                    <input
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="owner@pharmacy.et"
                        className="block w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm shadow-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-200"
                    />
                </label>

                <Button
                    type="submit"
                    variant="primary"
                    isLoading={isSending}
                    leftIcon={<Mail className="h-4 w-4" />}
                    className="mt-4 w-full"
                >
                    Send magic link
                </Button>

                {message && (
                    <p className="mt-3 text-center text-xs text-slate-500">{message}</p>
                )}
            </form>
        </div>
    );
}
