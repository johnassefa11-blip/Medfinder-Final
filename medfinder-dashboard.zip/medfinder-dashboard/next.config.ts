import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
    reactStrictMode: true,
    // Compress aggressively for slow networks in Ethiopia.
    compress: true,
    experimental: {
        // We use route groups, no extra experimental features required.
    },
    // Output a single trace for the local team to bundle-analyze.
    output: 'standalone',
};

export default nextConfig;
