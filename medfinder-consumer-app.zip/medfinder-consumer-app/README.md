# MedFinder — End-User App (Consumer)

A mobile-first Next.js 15 + Supabase + Tailwind web app for **patients and everyday users in Addis Ababa** to search for critical medicines and find the nearest verified pharmacy that has them in stock.

> Designed to feel instant on Ethiopian 3G: zero webfonts, no chart libraries, system icons only, and a Server Component shell that ships a stub of HTML before any JS runs.

---

## Table of Contents

1. [Architecture](#architecture)
2. [Quick Start](#quick-start)
3. [Project Layout](#project-layout)
4. [Part 1 — Search API](#part-1--search-api)
5. [Part 2 — Search UI](#part-2--search-ui)
6. [Sharing the Database with the Vendor App](#sharing-the-database-with-the-vendor-app)
7. [Extending the App](#extending-the-app)
8. [Troubleshooting](#troubleshooting)

---

## Architecture

```
┌──────────────────────┐   HTTPS   ┌──────────────────────┐
│  Patient browser     │ ────────▶ │  Next.js 15 (public) │
│  (mobile-first UI)   │           │  ┌────────────────┐  │
└──────────────────────┘           │  │  /search       │  │
                                  │  │  /api/search-  │  │
                                  │  │   medicine     │  │
                                  │  └───────┬────────┘  │
                                  └──────────┼───────────┘
                                             │ service-role
                                             ▼
                                  ┌──────────────────────┐
                                  │  Supabase Postgres   │
                                  │  search_medicines_   │
                                  │  nearby() RPC        │
                                  │  (Haversine + sort)  │
                                  └──────────────────────┘
```

- **No login required.** This is a public consumer app.
- **The API delegates the heavy lifting** (case-insensitive name match + Haversine distance + sort) to a single Postgres function `search_medicines_nearby`, so the database does the work and the JS bundle stays tiny.
- **RLS is bypassed server-side** using the service-role key. The route only ever returns public-safe fields (pharmacy name, location, price, distance) — no `owner_id`, no internal flags.
- **The page is a Server Component shell** (`/search/page.tsx`) plus a thin Client Component (`SearchClient.tsx`) that owns state via the `useMedicineSearch` hook.

---

## Quick Start

### 1. Install dependencies

```bash
cd medfinder-consumer-app
npm install
```

### 2. Apply the SQL schema

The consumer app shares its database with the **vendor dashboard**. Apply the schema once:

```bash
# In the Supabase SQL editor, run the vendor schema first…
psql "$DATABASE_URL" -f ../medfinder-vendor-dashboard/supabase/schema.sql

# …then run the consumer additions (search function, public RLS).
psql "$DATABASE_URL" -f supabase/schema.sql
```

Both scripts are idempotent. The consumer schema adds:

- A public RLS policy for `pharmacies` (verified only) and `pharmacy_inventory` (available + in-stock only).
- A new GIN trigram index on `medicines.generic_name`.
- A `search_medicines_nearby(...)` SQL function with `SECURITY DEFINER` + `STABLE` that returns sorted results with distance in km.
- A `GRANT EXECUTE` to the `anon` role so the function is callable from the browser client as well.

### 3. Configure environment variables

```bash
cp .env.local.example .env.local
```

Fill in:

```env
NEXT_PUBLIC_SUPABASE_URL=https://<project-ref>.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=<anon-key>
SUPABASE_SERVICE_ROLE_KEY=<service-role-key>
```

> The service-role key is **server-only** and is only read by `lib/supabase/server.ts`. It is never bundled into client JavaScript.

### 4. Run the dev server

```bash
npm run dev
```

Open <http://localhost:3000>. You'll land on `/search`.

---

## Project Layout

```
medfinder-consumer-app/
├── supabase/
│   └── schema.sql                          # Vendor superset + search RPC + public RLS
├── app/
│   ├── api/
│   │   └── search-medicine/
│   │       └── route.ts                    # Part 1 — Search API
│   ├── search/
│   │   ├── page.tsx                        # Part 2 — Server shell
│   │   └── SearchClient.tsx                # Part 2 — Client UI
│   ├── layout.tsx
│   ├── globals.css
│   └── page.tsx                            # Redirect → /search
├── components/
│   ├── ui/
│   │   ├── Button.tsx
│   │   └── Spinner.tsx
│   └── consumer/
│       ├── DistanceBadge.tsx               # Color-coded distance chip
│       ├── EmptyState.tsx                  # initial / no-results / error
│       ├── HeroHeader.tsx                  # Brand banner
│       ├── ProximityFilter.tsx             # "Within 2km / 5km / Anywhere" tabs
│       ├── ResultCard.tsx                  # Single search hit (with Call button)
│       └── SearchBar.tsx                   # Input + "Use Current Location"
├── hooks/
│   └── useMedicineSearch.ts                # Data hook with debounce + geo
├── lib/
│   ├── supabase/
│   │   ├── client.ts                       # Browser client
│   │   └── server.ts                       # Service-role client (server only)
│   ├── types/
│   │   ├── database.ts
│   │   └── index.ts
│   └── utils/
│       ├── format.ts                       # ETB, distance, severity helpers
│       └── geo.ts                          # Haversine + maps URL + Addis fallback
├── public/
├── package.json
├── tsconfig.json
├── next.config.ts
├── tailwind.config.ts
├── postcss.config.js
├── .env.local.example
├── .gitignore
└── README.md
```

---

## Part 1 — Search API

[`app/api/search-medicine/route.ts`](./app/api/search-medicine/route.ts)

### Request

```http
GET /api/search-medicine
  ?medicineName=paracetamol
  &userLatitude=9.0054
  &userLongitude=38.7636
  &maxDistanceKm=5           (optional)
  &limit=50                  (optional, default 50, max 100)
```

| Param            | Required | Notes                                            |
| ---------------- | :------: | ------------------------------------------------ |
| `medicineName`   |    ✅    | 2–120 chars, case-insensitive substring match    |
| `userLatitude`   |    ✅    | Decimal degrees, -90..90                         |
| `userLongitude`  |    ✅    | Decimal degrees, -180..180                       |
| `maxDistanceKm`  |    ❌    | Radius cap; omit for "Anywhere in Addis"          |
| `limit`          |    ❌    | 1–100, default 50                                 |

### Response

```json
{
  "ok": true,
  "data": [
    {
      "inventoryId": "…",
      "pharmacyId": "…",
      "pharmacyName": "Bole Pharmacy",
      "subCity": "Bole",
      "woreda": "Woreda 03",
      "phone": "+251911223344",
      "latitude": 9.0054,
      "longitude": 38.7636,
      "brandName": "Paracetamol 500mg",
      "genericName": "Acetaminophen",
      "category": "Analgesic",
      "manufacturer": "Cadila Pharmaceuticals",
      "stockQuantity": 50,
      "priceEtb": 125.0,
      "batchNumber": "BTH-2027-018",
      "expiryDate": "2027-08-31",
      "distanceKm": 0.84
    }
  ]
}
```

### Implementation notes

- All matching + distance math is delegated to the `search_medicines_nearby` SQL function, declared `SECURITY DEFINER` + `STABLE` so it can be safely called from many concurrent users. The Haversine formula lives in SQL — no need to fetch full rows to compute distance in JS.
- The route **only** returns fields safe for public consumption. Internal columns (`owner_id`, `is_verified`, `last_updated`, etc.) are stripped before serialization.
- Every branch is wrapped in `try / catch` with `console.error('[search-medicine][…]', err)` for explicit log tracing.
- Edge-cached for 30s with `stale-while-revalidate=120` so a busy moment in Bole doesn't stampede the database.

---

## Part 2 — Search UI

[`app/search/page.tsx`](./app/search/page.tsx) is a Server Component shell. All interactive state lives in [`SearchClient.tsx`](./app/search/SearchClient.tsx), composed of:

| Region              | Component                                          |
| ------------------- | -------------------------------------------------- |
| Hero (gradient)     | `HeroHeader` — brand + tagline + flag accent       |
| Search input        | `SearchBar` — input + clear + "Use Current Location" |
| Proximity filter    | `ProximityFilter` — 2km / 5km / Anywhere chips     |
| Live results        | `ResultCard` × N (one per matching inventory row)  |
| Empty / error       | `EmptyState` — three variants                      |

### `ResultCard` anatomy

```
┌─────────────────────────────────────────────────────┐
│ 💊  Paracetamol 500mg                 ETB 125.00  │
│     Acetaminophen · Cadila             per unit    │
│     ANALGESIC                                      │
├─────────────────────────────────────────────────────┤
│ [Bole Pharmacy] [Bole · Woreda 03] [📍 0.8 km]    │
├─────────────────────────────────────────────────────┤
│ 50 units in stock · batch BTH-2027-018            │
├─────────────────────────────────────────────────────┤
│ [   Directions   ]  [ 📞  Call +251911223344   ]  │
└─────────────────────────────────────────────────────┘
```

- **Price** is rendered in 24–30 px bold emerald type — the most prominent element on the card.
- **Distance badge** colour-codes by severity: emerald `< 1 km`, amber `1–3 km`, slate `> 3 km`.
- **Call button** is a real `<a href="tel:…">` so one tap opens the native dialer on iOS/Android. The button label includes the phone number, so the user can confirm before tapping.
- **Directions button** opens Google Maps in a new tab via a universal `https://www.google.com/maps/search/?api=1&…` URL.

### Mobile-first behaviours

- The whole page is a single column on phones. The search bar sits in a card that overlaps the hero by `-mt-6`, a common pattern that reads as a "search overlay".
- All tap targets are ≥ 44 px tall.
- `viewport` is set to `device-width, maximum-scale=5` so users can pinch-to-zoom if they need to read the pharmacy name.
- The `themeColor` is set to emerald-600 so the Safari/Chrome address bar matches the brand on mobile.

### Geolocation flow

1. The page loads with the **Addis Ababa fallback** (`9.0192° N, 38.7525° E`) as the centre of search.
2. Tapping **"Use current location"** calls `navigator.geolocation.getCurrentPosition` with an 8-second timeout.
3. If permission is granted, the user location updates and the search re-runs.
4. If permission is denied, the user sees an amber hint and results keep flowing from the Addis Ababa centre — the page remains useful.

### Debouncing

The search input is debounced 300 ms inside the hook. The "Searching…" pill is shown during the request so the user knows something is happening — but old results stay visible until the new ones arrive, so the UI never blanks out.

---

## Sharing the Database with the Vendor App

The two apps share one Supabase project. The lifecycle is:

1. **Vendor** signs in via `/login`, fills in their pharmacy row, manages inventory via `/vendor/dashboard`.
2. **Admin** (you) flips `is_verified = true` on the pharmacy row once KYC is complete.
3. **Customer** visits the consumer app and the verified pharmacy's inventory instantly appears in search results.

The Postgres function `search_medicines_nearby` enforces this server-side: it only returns rows where `pharmacies.is_verified = true` AND `pharmacy_inventory.is_available = true` AND `stock_quantity > 0`. So unverified vendors are invisible to consumers by construction.

---

## Extending the App

- **Add a new field to the result card** (e.g. opening hours) →
  1. Add the column to `pharmacies` in the schema and update `lib/types/database.ts`.
  2. Add it to the `RETURNS TABLE` clause of `search_medicines_nearby`.
  3. Add it to `MedicineSearchResult` in `lib/types/index.ts`.
  4. Project it in `projectRow()` in the API route.
  5. Render it in `ResultCard.tsx`.
- **Add a "Pick on map" UX** → call `setLocation({ latitude, longitude })` from `useMedicineSearch`.
- **Realtime inventory updates** → wire a `supabase.channel(…).on('postgres_changes', …)` in the hook and merge changes into `results`.
- **Rate-limiting** → wrap the route in an Upstash / Vercel KV limiter. The README in the vendor app has the same hint.

---

## Troubleshooting

| Symptom                                            | Fix                                                                 |
| -------------------------------------------------- | ------------------------------------------------------------------- |
| `permission denied for function search_medicines_nearby` | Re-run the schema; the `GRANT EXECUTE` line may have been skipped. |
| Always-empty results                               | Make sure at least one pharmacy has `is_verified = true` and has rows in `pharmacy_inventory` with `stock_quantity > 0`. |
| "Location permission denied" with no fallback      | The hook should automatically fall back to `ADDIS_ABABA_CENTER`. Check the browser console — `geoStatus` will be `'denied'`. |
| `Invalid API key` on first request                 | Double-check `.env.local`. The anon key + service-role key look similar. |
| Slow first search                                  | The RPC runs Haversine in SQL. If you have > 50k rows, consider adding a bounding-box pre-filter. |

---

## License

Proprietary — © MedFinder.
