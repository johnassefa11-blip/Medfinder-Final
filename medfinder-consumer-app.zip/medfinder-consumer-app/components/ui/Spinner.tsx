/**
 * Spinner — used inside buttons and search results while loading.
 */

import { Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils/format';

interface SpinnerProps {
    className?: string;
    label?: string;
}

export function Spinner({ className, label = 'Loading' }: SpinnerProps) {
    return (
        <span role="status" aria-label={label} className="inline-flex items-center">
            <Loader2 className={cn('h-5 w-5 animate-spin text-emerald-500', className)} />
            <span className="sr-only">{label}</span>
        </span>
    );
}
