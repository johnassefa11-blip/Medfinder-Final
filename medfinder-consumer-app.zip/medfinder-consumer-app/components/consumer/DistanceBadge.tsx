'use client';

/**
 * DistanceBadge — colour-coded chip that sits on the result card.
 *
 *   < 1 km   →  emerald "Very close"
 *   1–3 km   →  amber   "Nearby"
 *   > 3 km   →  slate   "A bit further"
 *
 * The colour and copy are derived from `distanceSeverity()`.
 */

import { MapPin } from 'lucide-react';
import { cn, distanceSeverity, distanceSeverityLabel, formatDistance } from '@/lib/utils/format';

const styleMap = {
    very_close: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
    close: 'bg-amber-50 text-amber-700 ring-amber-200',
    far: 'bg-slate-100 text-slate-700 ring-slate-200',
    unknown: 'bg-slate-100 text-slate-500 ring-slate-200',
} as const;

interface DistanceBadgeProps {
    km: number;
    compact?: boolean;
}

export function DistanceBadge({ km, compact = false }: DistanceBadgeProps) {
    const severity = distanceSeverity(km);
    return (
        <span
            className={cn(
                'inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset',
                styleMap[severity]
            )}
        >
            <MapPin className="h-3 w-3" />
            {formatDistance(km)}
            {!compact && (
                <span className="ml-0.5 text-[10px] font-normal opacity-75">
                    · {distanceSeverityLabel(severity)}
                </span>
            )}
        </span>
    );
}
