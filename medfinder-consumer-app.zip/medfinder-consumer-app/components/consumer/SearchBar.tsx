'use client';

/**
 * SearchBar — the headline input + "Use Current Location" button.
 *
 *  - Controlled input, debounced by the parent hook.
 *  - The "Use Current Location" button reflects geolocation state
 *    (idle / requesting / granted / denied).
 *  - Big, thumb-friendly tap targets for one-handed mobile use.
 */

import { useState, type FormEvent } from 'react';
import { Crosshair, Loader2, MapPin, Search, X } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { cn } from '@/lib/utils/format';
import type { GeolocationStatus } from '@/hooks/useMedicineSearch';

interface SearchBarProps {
    value: string;
    onChange: (v: string) => void;
    onSubmit?: (v: string) => void;
    geoStatus: GeolocationStatus;
    geoError: string | null;
    onUseCurrentLocation: () => void;
    hasUserLocation: boolean;
}

export function SearchBar({
    value,
    onChange,
    onSubmit,
    geoStatus,
    geoError,
    onUseCurrentLocation,
    hasUserLocation,
}: SearchBarProps) {
    const [touched, setTouched] = useState(false);

    function handleSubmit(e: FormEvent<HTMLFormElement>) {
        e.preventDefault();
        setTouched(true);
        onSubmit?.(value.trim());
    }

    const isLocating = geoStatus === 'requesting';

    return (
        <form onSubmit={handleSubmit} className="space-y-3" role="search">
            {/* ---- Text input ------------------------------------- */}
            <label className="block">
                <span className="sr-only">Search medicine</span>
                <div
                    className={cn(
                        'relative flex items-center rounded-2xl bg-white shadow-md ring-1 transition',
                        'focus-within:ring-2 focus-within:ring-emerald-500',
                        touched && value.trim().length < 2
                            ? 'ring-rose-300'
                            : 'ring-slate-200'
                    )}
                >
                    <Search
                        className="pointer-events-none absolute left-4 h-5 w-5 text-slate-400"
                        aria-hidden="true"
                    />
                    <input
                        type="search"
                        inputMode="search"
                        autoComplete="off"
                        spellCheck={false}
                        value={value}
                        onChange={(e) => onChange(e.target.value)}
                        placeholder="Search for a medicine (e.g. Paracetamol, Amoxil)"
                        className="block w-full rounded-2xl border-0 bg-transparent py-4 pl-12 pr-12 text-base text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-0"
                        aria-label="Medicine name"
                    />
                    {value && (
                        <button
                            type="button"
                            onClick={() => onChange('')}
                            aria-label="Clear search"
                            className="absolute right-2 rounded-full p-2 text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"
                        >
                            <X className="h-4 w-4" />
                        </button>
                    )}
                </div>
                {touched && value.trim().length < 2 && (
                    <p className="mt-1 text-xs text-rose-600">
                        Please type at least 2 characters.
                    </p>
                )}
            </label>

            {/* ---- Location button -------------------------------- */}
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                <Button
                    type="button"
                    variant="secondary"
                    onClick={onUseCurrentLocation}
                    isLoading={isLocating}
                    leftIcon={
                        isLocating ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                            <Crosshair className="h-4 w-4" />
                        )
                    }
                    className="w-full sm:w-auto"
                >
                    {hasUserLocation ? 'Refresh my location' : 'Use current location'}
                </Button>

                {hasUserLocation ? (
                    <p className="flex items-center gap-1.5 text-xs text-emerald-700">
                        <MapPin className="h-3.5 w-3.5" />
                        Searching near your live location
                    </p>
                ) : geoError ? (
                    <p className="text-xs text-amber-700">{geoError}</p>
                ) : (
                    <p className="text-xs text-slate-500">
                        Tip: enable location for nearby results.
                    </p>
                )}
            </div>
        </form>
    );
}
