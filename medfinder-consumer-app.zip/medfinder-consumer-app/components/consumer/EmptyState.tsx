'use client';

/**
 * Empty / error / initial states for the search results feed.
 *
 * Three flavours:
 *   - "initial"   — no query yet, show helpful tips
 *   - "no-results"— query ran, no hits
 *   - "error"     — server / network error
 */

import { AlertCircle, MapPin, Search, Sparkles } from 'lucide-react';
import type { ReactNode } from 'react';

type Variant = 'initial' | 'no-results' | 'error';

interface EmptyStateProps {
    variant: Variant;
    title?: string;
    description?: ReactNode;
}

const COPY: Record<
    Variant,
    { title: string; description: ReactNode; Icon: typeof Search }
> = {
    initial: {
        title: 'Find medicine near you',
        description: (
            <>
                Type the name of any medicine (brand or generic) to see which
                verified pharmacies in Addis Ababa have it in stock right now.
            </>
        ),
        Icon: Sparkles,
    },
    'no-results': {
        title: 'No matches in this area',
        description: (
            <>
                We couldn't find that medicine within the selected distance.
                Try widening the radius or searching for the generic name
                (e.g. <em>Acetaminophen</em> instead of <em>Panadol</em>).
            </>
        ),
        Icon: Search,
    },
    error: {
        title: 'Something went wrong',
        description: (
            <>We couldn't reach the search service. Please check your connection and try again.</>
        ),
        Icon: AlertCircle,
    },
};

const TONE: Record<Variant, string> = {
    initial: 'bg-emerald-50 text-emerald-600',
    'no-results': 'bg-amber-50 text-amber-600',
    error: 'bg-rose-50 text-rose-600',
};

export function EmptyState({ variant, title, description }: EmptyStateProps) {
    const copy = COPY[variant];
    const Icon = copy.Icon;

    return (
        <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-200 bg-white/60 px-6 py-12 text-center">
            <div
                className={`flex h-12 w-12 items-center justify-center rounded-full ${TONE[variant]}`}
            >
                <Icon className="h-6 w-6" />
            </div>
            <h3 className="mt-4 text-base font-semibold text-slate-900">
                {title ?? copy.title}
            </h3>
            <p className="mt-1 max-w-md text-sm text-slate-500">
                {description ?? copy.description}
            </p>

            {variant === 'initial' && (
                <ul className="mt-6 grid w-full max-w-md grid-cols-1 gap-2 text-left text-sm text-slate-600 sm:grid-cols-2">
                    <li className="flex items-start gap-2">
                        <Search className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" />
                        Search by brand or generic name
                    </li>
                    <li className="flex items-start gap-2">
                        <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" />
                        Use your live location
                    </li>
                    <li className="flex items-start gap-2">
                        <Phone className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" />
                        Tap to call the pharmacy
                    </li>
                    <li className="flex items-start gap-2">
                        <Sparkles className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" />
                        Only verified pharmacies
                    </li>
                </ul>
            )}
        </div>
    );
}
