/**
 * HeroHeader — the top of the search page.
 *
 * Pure server-friendly component (no client state). The brand mark,
 * tagline, and a subtle Ethiopian-flag gradient bar at the top.
 */

import { HeartPulse, MapPin } from 'lucide-react';

export function HeroHeader() {
    return (
        <header className="relative overflow-hidden bg-gradient-to-br from-emerald-600 via-emerald-600 to-teal-700 text-white">
            {/* Ethiopian flag accent stripe */}
            <div className="absolute inset-x-0 top-0 h-1 flex">
                <div className="flex-1 bg-emerald-400" />
                <div className="flex-1 bg-yellow-300" />
                <div className="flex-1 bg-rose-500" />
            </div>

            <div className="mx-auto flex max-w-3xl flex-col items-center gap-3 px-4 pb-10 pt-12 text-center sm:px-6 sm:pt-16">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/15 ring-1 ring-inset ring-white/30 backdrop-blur">
                    <HeartPulse className="h-6 w-6" />
                </div>
                <h1 className="text-2xl font-semibold sm:text-3xl">MedFinder</h1>
                <p className="max-w-md text-sm text-white/85 sm:text-base">
                    Find critical medicines and the nearest verified pharmacy
                    in Addis Ababa — in seconds.
                </p>
                <p className="mt-1 flex items-center gap-1.5 text-xs text-white/70">
                    <MapPin className="h-3.5 w-3.5" />
                    Currently serving Addis Ababa
                </p>
            </div>
        </header>
    );
}
