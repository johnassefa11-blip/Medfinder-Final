'use client';

/**
 * ProximityFilter — three pill buttons that cap the search radius.
 *
 *   "Within 2 km"  →  2 km radius
 *   "Within 5 km"  →  5 km radius
 *   "Anywhere"     →  no cap
 *
 * The selected option gets an emerald pill; the others sit on a
 * subtle slate background. Whole thing is a single row on mobile
 * (wraps gracefully) and a horizontal row on tablet+.
 */

import { cn } from '@/lib/utils/format';

export type ProximityOption = {
    id: 'near' | 'medium' | 'anywhere';
    label: string;
    /** Max distance in km, or `null` for "anywhere". */
    maxKm: number | null;
};

export const PROXIMITY_OPTIONS: ProximityOption[] = [
    { id: 'near', label: 'Within 2 km', maxKm: 2 },
    { id: 'medium', label: 'Within 5 km', maxKm: 5 },
    { id: 'anywhere', label: 'Anywhere in Addis', maxKm: null },
];

interface ProximityFilterProps {
    value: ProximityOption['id'];
    onChange: (id: ProximityOption['id']) => void;
    resultCount: number;
}

export function ProximityFilter({ value, onChange, resultCount }: ProximityFilterProps) {
    return (
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
            <div
                role="tablist"
                aria-label="Filter results by distance"
                className="inline-flex flex-wrap gap-1.5 rounded-2xl bg-white p-1.5 shadow-sm ring-1 ring-slate-200"
            >
                {PROXIMITY_OPTIONS.map((opt) => {
                    const active = opt.id === value;
                    return (
                        <button
                            key={opt.id}
                            type="button"
                            role="tab"
                            aria-selected={active}
                            onClick={() => onChange(opt.id)}
                            className={cn(
                                'rounded-xl px-3.5 py-2 text-sm font-medium transition',
                                active
                                    ? 'bg-emerald-600 text-white shadow-sm'
                                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                            )}
                        >
                            {opt.label}
                        </button>
                    );
                })}
            </div>

            <p className="text-xs text-slate-500">
                <span className="font-semibold text-slate-700">{resultCount}</span>{' '}
                {resultCount === 1 ? 'result' : 'results'}
            </p>
        </div>
    );
}
