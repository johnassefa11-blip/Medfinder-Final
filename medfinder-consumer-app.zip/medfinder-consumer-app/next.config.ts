import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
    reactStrictMode: true,
    // Compress aggressively for slow networks in Ethiopia.
    compress: true,
    output: 'standalone',
};

export default nextConfig;
