/**
 * Root index — bounces to /search.
 *
 * The consumer app has only one screen, so the root is a no-frills
 * redirect.
 */

import { redirect } from 'next/navigation';

export default function HomePage() {
    redirect('/search');
}
