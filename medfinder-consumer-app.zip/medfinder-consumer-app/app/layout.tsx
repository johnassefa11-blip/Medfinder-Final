/**
 * Root layout for the MedFinder consumer app.
 *
 *  - System font stack (zero network cost).
 *  - Tailwind global styles.
 *  - Light theme metadata for browser chrome.
 */

import type { Metadata, Viewport } from 'next';
import './globals.css';

export const metadata: Metadata = {
    title: {
        default: 'MedFinder — Find Medicine in Addis Ababa',
        template: '%s · MedFinder',
    },
    description:
        'Find critical medicines and the nearest verified pharmacy in Addis Ababa — in seconds.',
    applicationName: 'MedFinder',
    authors: [{ name: 'MedFinder' }],
    openGraph: {
        title: 'MedFinder',
        description: 'Find critical medicines and the nearest verified pharmacy in Addis Ababa.',
        type: 'website',
    },
};

export const viewport: Viewport = {
    width: 'device-width',
    initialScale: 1,
    maximumScale: 5,
    themeColor: '#059669', // emerald-600 — matches the brand
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
    return (
        <html lang="en" className="bg-slate-50">
            <body className="min-h-screen bg-slate-50 font-sans text-slate-900 antialiased">
                {children}
            </body>
        </html>
    );
}
