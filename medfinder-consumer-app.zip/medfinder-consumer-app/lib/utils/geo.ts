/**
 * Geographic helpers.
 *
 * The consumer app does all of its geo work in JavaScript so the
 * `search_medicines_nearby` SQL function can stay simple. The
 * Haversine formula gives us sub-1% accuracy for distances < 100 km,
 * which is exactly the range we care about inside Addis Ababa.
 */

/** Earth radius in kilometres (mean). */
const EARTH_RADIUS_KM = 6371;

const toRad = (deg: number): number => (deg * Math.PI) / 180;

/**
 * Great-circle distance between two lat/lon pairs, in kilometres.
 * Returns `NaN` if any input is `null` / `undefined` / `NaN`.
 */
export function haversineKm(
    lat1: number,
    lon1: number,
    lat2: number,
    lon2: number
): number {
    if (
        !Number.isFinite(lat1) ||
        !Number.isFinite(lon1) ||
        !Number.isFinite(lat2) ||
        !Number.isFinite(lon2)
    ) {
        return Number.NaN;
    }
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a =
        Math.sin(dLat / 2) ** 2 +
        Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return EARTH_RADIUS_KM * c;
}

/** Friendly distance label, e.g. "850 m", "3.4 km", "12 km". */
export function formatDistance(km: number | null | undefined): string {
    if (km == null || !Number.isFinite(km)) return '—';
    if (km < 1) return `${Math.max(1, Math.round(km * 1000))} m`;
    if (km < 10) return `${km.toFixed(1)} km`;
    return `${Math.round(km)} km`;
}

/** A short map URL for the pharmacy pin (works on iOS, Android, and web). */
export function mapsUrl(lat: number, lon: number, label?: string): string {
    const q = label ? encodeURIComponent(label) : `${lat},${lon}`;
    return `https://www.google.com/maps/search/?api=1&query=${q}&center=${lat},${lon}`;
}

/** Centre of Addis Ababa — used as a graceful fallback when the user
 *  denies geolocation permission. (Bole area, 9.0054° N, 38.7636° E.) */
export const ADDIS_ABABA_CENTER = {
    latitude: 9.0192,
    longitude: 38.7525,
} as const;
