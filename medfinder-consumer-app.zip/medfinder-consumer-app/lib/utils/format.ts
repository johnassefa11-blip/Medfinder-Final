/**
 * Formatting helpers for the consumer UI.
 *
 * No React, no Supabase — just data → displayable string.
 */

import type { MedicineSearchResult } from '@/lib/types';

/* -------------------------------------------------------------------------- */
/*  Currency                                                                  */
/* -------------------------------------------------------------------------- */

/**
 * Format a number as Ethiopian Birr.
 * Examples:
 *   formatEtb(500)   → "ETB 500.00"
 *   formatEtb(125.5) → "ETB 125.50"
 *   formatEtb(null)  → "ETB —"
 */
export function formatEtb(value: number | string | null | undefined): string {
    const n = typeof value === 'string' ? Number(value) : value ?? NaN;
    if (!Number.isFinite(n)) return 'ETB —';
    return new Intl.NumberFormat('en-ET', {
        style: 'currency',
        currency: 'ETB',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    }).format(n);
}

/** Short ETB rendering, no trailing .00 — used for prominent price text. */
export function formatEtbShort(value: number | string | null | undefined): string {
    const n = typeof value === 'string' ? Number(value) : value ?? NaN;
    if (!Number.isFinite(n)) return '—';
    return new Intl.NumberFormat('en-ET', {
        style: 'currency',
        currency: 'ETB',
        minimumFractionDigits: Number.isInteger(n) ? 0 : 2,
        maximumFractionDigits: 2,
    }).format(n);
}

/* -------------------------------------------------------------------------- */
/*  Phone                                                                     */
/* -------------------------------------------------------------------------- */

/** Normalise a phone number for `tel:` links. */
export function telHref(phone: string | null | undefined): string {
    if (!phone) return '#';
    // Strip whitespace, brackets, dashes; keep `+` and digits.
    return `tel:${phone.replace(/[^\d+]/g, '')}`;
}

/* -------------------------------------------------------------------------- */
/*  Class-name joiner                                                         */
/* -------------------------------------------------------------------------- */

export function cn(...parts: Array<string | false | null | undefined>): string {
    return parts.filter(Boolean).join(' ');
}

/* -------------------------------------------------------------------------- */
/*  Severity bucketing for the distance badge                                 */
/* -------------------------------------------------------------------------- */

export type DistanceSeverity = 'very_close' | 'close' | 'far' | 'unknown';

export function distanceSeverity(km: number | null | undefined): DistanceSeverity {
    if (km == null || !Number.isFinite(km)) return 'unknown';
    if (km < 1) return 'very_close';
    if (km < 3) return 'close';
    return 'far';
}

export function distanceSeverityLabel(s: DistanceSeverity): string {
    switch (s) {
        case 'very_close':
            return 'Very close';
        case 'close':
            return 'Nearby';
        case 'far':
            return 'A bit further';
        case 'unknown':
            return '—';
    }
}

/* -------------------------------------------------------------------------- */
/*  Sort / filter helpers                                                     */
/* -------------------------------------------------------------------------- */

/** Sort results by ascending distance. Stable. */
export function sortByDistance(rows: MedicineSearchResult[]): MedicineSearchResult[] {
    return [...rows].sort((a, b) => a.distanceKm - b.distanceKm);
}

/** Filter by a max-distance cap (km). Pass `null`/`undefined` to keep all. */
export function filterByDistance(
    rows: MedicineSearchResult[],
    maxKm: number | null | undefined
): MedicineSearchResult[] {
    if (maxKm == null || !Number.isFinite(maxKm)) return rows;
    return rows.filter((r) => r.distanceKm <= maxKm);
}
