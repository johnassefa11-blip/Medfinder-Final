/**
 * Hand-written Supabase database typings.
 *
 * Keep this in sync with the SQL schema. The minimal subset used by
 * the consumer app is exported here.
 */

export type Json =
    | string
    | number
    | boolean
    | null
    | { [key: string]: Json | undefined }
    | Json[];

export interface Database {
    public: {
        Tables: {
            pharmacies: {
                Row: {
                    id: string;
                    name: string;
                    owner_id: string;
                    phone: string;
                    sub_city: string;
                    woreda: string;
                    latitude: number | null;
                    longitude: number | null;
                    is_verified: boolean;
                    created_at: string;
                };
                Insert: Partial<Database['public']['Tables']['pharmacies']['Row']> & {
                    name: string;
                    owner_id: string;
                    phone: string;
                    sub_city: string;
                    woreda: string;
                };
                Update: Partial<Database['public']['Tables']['pharmacies']['Insert']>;
                Relationships: [];
            };
            medicines: {
                Row: {
                    id: string;
                    brand_name: string;
                    generic_name: string;
                    category: string;
                    manufacturer: string | null;
                    created_at: string;
                };
                Insert: {
                    id?: string;
                    brand_name: string;
                    generic_name: string;
                    category: string;
                    manufacturer?: string | null;
                    created_at?: string;
                };
                Update: Partial<Database['public']['Tables']['medicines']['Insert']>;
                Relationships: [];
            };
            pharmacy_inventory: {
                Row: {
                    id: string;
                    pharmacy_id: string;
                    medicine_id: string;
                    stock_quantity: number;
                    price_etb: number;
                    batch_number: string;
                    expiry_date: string;
                    is_available: boolean;
                    last_updated: string;
                    created_at: string;
                };
                Insert: {
                    id?: string;
                    pharmacy_id: string;
                    medicine_id: string;
                    stock_quantity?: number;
                    price_etb: number;
                    batch_number: string;
                    expiry_date: string;
                    is_available?: boolean;
                    last_updated?: string;
                    created_at?: string;
                };
                Update: Partial<Database['public']['Tables']['pharmacy_inventory']['Insert']>;
                Relationships: [];
            };
        };
        Views: Record<string, never>;
        Functions: {
            search_medicines_nearby: {
                Args: {
                    search_query: string;
                    user_lat: number;
                    user_lon: number;
                    max_distance_km?: number | null;
                    result_limit?: number;
                };
                Returns: Array<{
                    inventory_id: string;
                    pharmacy_id: string;
                    pharmacy_name: string;
                    sub_city: string;
                    woreda: string;
                    phone: string;
                    latitude: number;
                    longitude: number;
                    brand_name: string;
                    generic_name: string;
                    category: string;
                    manufacturer: string | null;
                    stock_quantity: number;
                    price_etb: number;
                    batch_number: string;
                    expiry_date: string;
                    distance_km: number;
                }>;
            };
        };
        Enums: Record<string, never>;
    };
}
