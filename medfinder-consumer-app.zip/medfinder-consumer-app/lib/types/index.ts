/**
 * Application-level types — the shapes the UI actually consumes.
 */

import type { Database } from './database';

/* -------------------------------------------------------------------------- */
/*  Search                                                                    */
/* -------------------------------------------------------------------------- */

/** One row of search-medicine API output, after light projection. */
export interface MedicineSearchResult {
    inventoryId: string;
    pharmacyId: string;
    pharmacyName: string;
    subCity: string;
    woreda: string;
    phone: string;
    latitude: number;
    longitude: number;
    brandName: string;
    genericName: string;
    category: string;
    manufacturer: string | null;
    stockQuantity: number;
    priceEtb: number;
    batchNumber: string;
    expiryDate: string;
    distanceKm: number;
}

/** API request query for /api/search-medicine. */
export interface SearchMedicineQuery {
    /** Free-text medicine name. Trimmed + lower-cased server-side. */
    medicineName: string;
    /** Decimal degrees, -90..90. */
    userLatitude: number;
    /** Decimal degrees, -180..180. */
    userLongitude: number;
    /** Optional radius cap in km. Omit = "anywhere in Addis". */
    maxDistanceKm?: number;
    /** Result cap. Default 50, max 100. */
    limit?: number;
}

/** Standard JSON envelope returned by the API. */
export type ApiResponse<T> =
    | { ok: true; data: T }
    | { ok: false; error: string; details?: unknown };

/* -------------------------------------------------------------------------- */
/*  Re-exports                                                                */
/* -------------------------------------------------------------------------- */

export type Medicine = Database['public']['Tables']['medicines']['Row'];
export type Pharmacy = Database['public']['Tables']['pharmacies']['Row'];
