/**
 * Browser-side Supabase client.
 *
 * The consumer app is fully public — this client is used for any
 * client-side Supabase calls (e.g. realtime subscriptions in a
 * later iteration). For the search page itself we hit our own
 * /api/search-medicine endpoint instead of going through Supabase
 * directly so we can shape the response and add caching.
 */

import { createBrowserClient } from '@supabase/ssr';
import type { Database } from '@/lib/types/database';

export function createSupabaseBrowserClient() {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

    if (!supabaseUrl || !supabaseAnonKey) {
        throw new Error(
            '[supabase/client] Missing NEXT_PUBLIC_SUPABASE_URL or NEXT_PUBLIC_SUPABASE_ANON_KEY.'
        );
    }

    return createBrowserClient<Database>(supabaseUrl, supabaseAnonKey);
}
