/**
 * Server-side Supabase client (consumer app).
 *
 * For unauthenticated public reads we use the **service-role** key.
 * That key bypasses RLS — the trade-off is fine because:
 *
 *   1. It never leaves the server (this file is server-only).
 *   2. The API routes that use it are the *only* place we expose
 *      consumer-facing data, and they project only safe public
 *      fields (no `owner_id`, no `auth.users.*`, no internal flags).
 *
 * If you add write paths, switch to the user-context client so RLS
 * can do its job.
 */

import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import type { Database } from '@/lib/types/database';

let _serviceClient: SupabaseClient<Database> | null = null;

/**
 * Service-role client. Bypasses RLS. **Server-only**.
 */
export function createSupabaseServiceClient(): SupabaseClient<Database> {
    if (_serviceClient) return _serviceClient;

    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const serviceKey =
        process.env.SUPABASE_SERVICE_ROLE_KEY ||
        // Fallback to anon if service-role is not yet configured.
        // Reads will then go through RLS (see `search_medicines_nearby`).
        process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

    if (!supabaseUrl || !serviceKey) {
        throw new Error(
            '[supabase/server] Missing Supabase credentials. Set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in .env.local.'
        );
    }

    _serviceClient = createClient<Database>(supabaseUrl, serviceKey, {
        auth: {
            persistSession: false,
            autoRefreshToken: false,
        },
    });
    return _serviceClient;
}
