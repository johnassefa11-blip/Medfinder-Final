'use client';

/**
 * useMedicineSearch — single source of truth for the search page.
 *
 * Owns:
 *   - The current query (medicine name + user location + max distance).
 *   - Debounced fetching of /api/search-medicine.
 *   - Loading + error state.
 *   - Geolocation (request, error states, default fallback to
 *     Addis Ababa centre when permission is denied).
 *
 * The hook deliberately does NOT own UI state — that's the caller's job.
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import type {
    ApiResponse,
    MedicineSearchResult,
} from '@/lib/types';
import { ADDIS_ABABA_CENTER } from '@/lib/utils/geo';

export type GeolocationStatus = 'idle' | 'requesting' | 'granted' | 'denied' | 'unavailable';

interface UseMedicineSearchState {
    query: string;
    setQuery: (q: string) => void;
    /** Current user location (or fallback). */
    userLocation: { latitude: number; longitude: number };
    /** Status of the geolocation request. */
    geoStatus: GeolocationStatus;
    geoError: string | null;
    /** Manually (re)request the browser's geolocation. */
    requestLocation: () => Promise<void>;
    /** Manually set a location (e.g. from a future "pick on map" UX). */
    setLocation: (loc: { latitude: number; longitude: number }) => void;

    /** Currently selected distance cap (km), or null for "anywhere". */
    maxDistanceKm: number | null;
    setMaxDistanceKm: (km: number | null) => void;

    results: MedicineSearchResult[];
    isLoading: boolean;
    error: string | null;
    hasSearched: boolean;
}

const DEBOUNCE_MS = 300;

export function useMedicineSearch(): UseMedicineSearchState {
    const [query, setQuery] = useState('');
    const [userLocation, setUserLocation] = useState(ADDIS_ABABA_CENTER);
    const [geoStatus, setGeoStatus] = useState<GeolocationStatus>('idle');
    const [geoError, setGeoError] = useState<string | null>(null);
    const [maxDistanceKm, setMaxDistanceKm] = useState<number | null>(null);

    const [results, setResults] = useState<MedicineSearchResult[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [hasSearched, setHasSearched] = useState(false);

    // Track the in-flight request so out-of-order responses can't
    // overwrite a newer one.
    const requestIdRef = useRef(0);

    /* ------------------------ geolocation ------------------------------ */
    const requestLocation = useCallback(async () => {
        if (typeof window === 'undefined' || !('geolocation' in navigator)) {
            setGeoStatus('unavailable');
            setGeoError("Your browser doesn't support geolocation.");
            return;
        }

        setGeoStatus('requesting');
        setGeoError(null);

        return new Promise<void>((resolve) => {
            navigator.geolocation.getCurrentPosition(
                (pos) => {
                    setUserLocation({
                        latitude: pos.coords.latitude,
                        longitude: pos.coords.longitude,
                    });
                    setGeoStatus('granted');
                    resolve();
                },
                (err) => {
                    // Stay on the Addis Ababa fallback so the page
                    // remains useful even without GPS.
                    setGeoStatus('denied');
                    setGeoError(
                        err.code === err.PERMISSION_DENIED
                            ? 'Location permission denied. Showing results around Addis Ababa.'
                            : 'Could not detect your location. Showing results around Addis Ababa.'
                    );
                    setUserLocation(ADDIS_ABABA_CENTER);
                    resolve();
                },
                {
                    enableHighAccuracy: false,
                    timeout: 8_000,
                    maximumAge: 60_000,
                }
            );
        });
    }, []);

    /* ------------------------ search (debounced) ----------------------- */
    useEffect(() => {
        const trimmed = query.trim();
        if (trimmed.length < 2) {
            setResults([]);
            setHasSearched(false);
            setError(null);
            setIsLoading(false);
            return;
        }

        const myId = ++requestIdRef.current;
        const handle = window.setTimeout(async () => {
            setIsLoading(true);
            setError(null);
            try {
                const params = new URLSearchParams({
                    medicineName: trimmed,
                    userLatitude: String(userLocation.latitude),
                    userLongitude: String(userLocation.longitude),
                });
                if (maxDistanceKm != null) {
                    params.set('maxDistanceKm', String(maxDistanceKm));
                }
                const res = await fetch(`/api/search-medicine?${params.toString()}`, {
                    cache: 'no-store',
                });
                if (myId !== requestIdRef.current) return; // stale

                const json = (await res.json()) as ApiResponse<MedicineSearchResult[]>;
                if (myId !== requestIdRef.current) return;

                if (!json.ok) {
                    setError(json.error);
                    setResults([]);
                } else {
                    setResults(json.data);
                    setHasSearched(true);
                }
            } catch (e) {
                if (myId !== requestIdRef.current) return;
                console.error('[useMedicineSearch] fetch failed:', e);
                setError('Network error. Please check your connection.');
                setResults([]);
            } finally {
                if (myId === requestIdRef.current) {
                    setIsLoading(false);
                }
            }
        }, DEBOUNCE_MS);

        return () => window.clearTimeout(handle);
    }, [query, userLocation, maxDistanceKm]);

    return {
        query,
        setQuery,
        userLocation,
        geoStatus,
        geoError,
        requestLocation,
        setLocation: setUserLocation,
        maxDistanceKm,
        setMaxDistanceKm,
        results,
        isLoading,
        error,
        hasSearched,
    };
}
