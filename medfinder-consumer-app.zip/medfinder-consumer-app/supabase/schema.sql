-- =============================================================================
-- MedFinder Consumer App — Supabase / PostgreSQL Schema
-- =============================================================================
-- This file is a superset of the vendor-dashboard schema. It adds:
--   * a public read policy for verified pharmacies + their inventory
--   * a SECURITY DEFINER RPC function that powers the search-medicine API
--   * an updated RLS posture for the consumer-facing data
--
-- Run the vendor `schema.sql` first, then apply the additions at the
-- bottom of this file.  Everything in here is idempotent.
-- =============================================================================


-- ---------------------------------------------------------------------------
-- 0. EXTENSIONS  (mirror the vendor setup)
-- ---------------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS pg_trgm;
-- CREATE EXTENSION IF NOT EXISTS postgis; -- optional: real geo queries


-- ---------------------------------------------------------------------------
-- 1. TABLES  (mirror the vendor schema — same shape, same constraints)
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.pharmacies (
    id           UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    name         TEXT         NOT NULL CHECK (char_length(name) BETWEEN 2 AND 120),
    owner_id     UUID         NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    phone        TEXT         NOT NULL CHECK (phone ~ '^\+?[0-9]{7,15}$'),
    sub_city     TEXT         NOT NULL,
    woreda       TEXT         NOT NULL,
    latitude     DOUBLE PRECISION CHECK (latitude  BETWEEN -90  AND 90),
    longitude    DOUBLE PRECISION CHECK (longitude BETWEEN -180 AND 180),
    is_verified  BOOLEAN      NOT NULL DEFAULT FALSE,
    created_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    CONSTRAINT pharmacies_owner_id_key UNIQUE (owner_id)
);

CREATE TABLE IF NOT EXISTS public.medicines (
    id            UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    brand_name    TEXT         NOT NULL CHECK (char_length(brand_name) BETWEEN 1 AND 120),
    generic_name  TEXT         NOT NULL CHECK (char_length(generic_name) BETWEEN 1 AND 120),
    category      TEXT         NOT NULL,
    manufacturer  TEXT,
    created_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS medicines_brand_generic_unique_idx
    ON public.medicines (LOWER(brand_name), LOWER(generic_name));

CREATE TABLE IF NOT EXISTS public.pharmacy_inventory (
    id              UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    pharmacy_id     UUID         NOT NULL REFERENCES public.pharmacies(id)    ON DELETE CASCADE,
    medicine_id     UUID         NOT NULL REFERENCES public.medicines(id)     ON DELETE RESTRICT,
    stock_quantity  INTEGER      NOT NULL DEFAULT 0 CHECK (stock_quantity >= 0),
    price_etb       NUMERIC(10,2) NOT NULL CHECK (price_etb >= 0),
    batch_number    TEXT         NOT NULL,
    expiry_date     DATE         NOT NULL,
    is_available    BOOLEAN      NOT NULL DEFAULT TRUE,
    last_updated    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    CONSTRAINT pharmacy_inventory_unique_batch UNIQUE (pharmacy_id, medicine_id, batch_number)
);


-- ---------------------------------------------------------------------------
-- 2. INDEXES
-- ---------------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS pharmacy_inventory_pharmacy_id_idx
    ON public.pharmacy_inventory (pharmacy_id);
CREATE INDEX IF NOT EXISTS pharmacy_inventory_medicine_id_idx
    ON public.pharmacy_inventory (medicine_id);
CREATE INDEX IF NOT EXISTS pharmacy_inventory_availability_idx
    ON public.pharmacy_inventory (pharmacy_id, is_available);
CREATE INDEX IF NOT EXISTS pharmacy_inventory_expiry_idx
    ON public.pharmacy_inventory (pharmacy_id, expiry_date);

-- Fuzzy search on the catalogue
CREATE INDEX IF NOT EXISTS medicines_brand_name_trgm_idx
    ON public.medicines USING gin (LOWER(brand_name) gin_trgm_ops);
CREATE INDEX IF NOT EXISTS medicines_generic_name_trgm_idx
    ON public.medicines USING gin (LOWER(generic_name) gin_trgm_ops);

-- Geo index (good enough for bounding-box queries in MVP)
CREATE INDEX IF NOT EXISTS pharmacies_lat_lon_idx
    ON public.pharmacies (latitude, longitude);
-- Filter on verified pharmacies
CREATE INDEX IF NOT EXISTS pharmacies_verified_idx
    ON public.pharmacies (is_verified) WHERE is_verified = TRUE;


-- ---------------------------------------------------------------------------
-- 3. TRIGGERS
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.set_last_updated()
RETURNS TRIGGER AS $$
BEGIN
    NEW.last_updated = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_pharmacy_inventory_set_last_updated ON public.pharmacy_inventory;
CREATE TRIGGER trg_pharmacy_inventory_set_last_updated
    BEFORE UPDATE ON public.pharmacy_inventory
    FOR EACH ROW
    EXECUTE FUNCTION public.set_last_updated();


-- ---------------------------------------------------------------------------
-- 4. RLS POLICIES
-- ---------------------------------------------------------------------------
-- Vendor app keeps the strict owner-only policies. The consumer app needs
-- a *public read* of verified pharmacies + their available inventory.
-- We expose a separate, narrow SELECT policy for the `anon` role.
-- ---------------------------------------------------------------------------

ALTER TABLE public.pharmacies          ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.medicines           ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pharmacy_inventory  ENABLE ROW LEVEL SECURITY;

-- Drop policies (idempotency)
DROP POLICY IF EXISTS pharmacies_select_own        ON public.pharmacies;
DROP POLICY IF EXISTS pharmacies_insert_self       ON public.pharmacies;
DROP POLICY IF EXISTS pharmacies_update_own        ON public.pharmacies;
DROP POLICY IF EXISTS pharmacies_select_verified   ON public.pharmacies;
DROP POLICY IF EXISTS medicines_select_all         ON public.medicines;
DROP POLICY IF EXISTS medicines_insert_auth        ON public.medicines;
DROP POLICY IF EXISTS inventory_select_own         ON public.pharmacy_inventory;
DROP POLICY IF EXISTS inventory_modify_own         ON public.pharmacy_inventory;
DROP POLICY IF EXISTS inventory_select_public      ON public.pharmacy_inventory;

-- Vendor-side policies (must match the vendor app)
CREATE POLICY pharmacies_select_own
    ON public.pharmacies FOR SELECT
    USING (auth.uid() = owner_id);
CREATE POLICY pharmacies_insert_self
    ON public.pharmacies FOR INSERT
    WITH CHECK (auth.uid() = owner_id);
CREATE POLICY pharmacies_update_own
    ON public.pharmacies FOR UPDATE
    USING (auth.uid() = owner_id)
    WITH CHECK (auth.uid() = owner_id);

CREATE POLICY medicines_select_all
    ON public.medicines FOR SELECT USING (TRUE);
CREATE POLICY medicines_insert_auth
    ON public.medicines FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY inventory_select_own
    ON public.pharmacy_inventory FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM public.pharmacies p
            WHERE p.id = pharmacy_inventory.pharmacy_id
              AND p.owner_id = auth.uid()
        )
    );
CREATE POLICY inventory_modify_own
    ON public.pharmacy_inventory FOR ALL
    USING (
        EXISTS (
            SELECT 1 FROM public.pharmacies p
            WHERE p.id = pharmacy_inventory.pharmacy_id
              AND p.owner_id = auth.uid()
        )
    )
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM public.pharmacies p
            WHERE p.id = pharmacy_inventory.pharmacy_id
              AND p.owner_id = auth.uid()
        )
    );

-- Consumer-side public read policies
CREATE POLICY pharmacies_select_verified
    ON public.pharmacies FOR SELECT
    TO anon
    USING (is_verified = TRUE);

CREATE POLICY inventory_select_public
    ON public.pharmacy_inventory FOR SELECT
    TO anon
    USING (
        is_available = TRUE
        AND stock_quantity > 0
        AND EXISTS (
            SELECT 1 FROM public.pharmacies p
            WHERE p.id = pharmacy_inventory.pharmacy_id
              AND p.is_verified = TRUE
        )
    );


-- ---------------------------------------------------------------------------
-- 5. SEARCH RPC FUNCTION
-- ---------------------------------------------------------------------------
-- The consumer /api/search-medicine route delegates the heavy lifting
-- (matching + Haversine distance + sorting) to this function. It is
-- declared SECURITY DEFINER + STABLE so it can run in parallel for
-- many concurrent end-users.
--
-- Inputs:
--   search_query     text                – case-insensitive substring
--   user_lat         double precision    – decimal degrees
--   user_lon         double precision    – decimal degrees
--   max_distance_km  double precision    – optional radius cap (NULL = no cap)
--   result_limit     integer             – default 50, max 100
--
-- Returns one row per matching inventory line, sorted by ascending
-- distance, with the distance in km included.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.search_medicines_nearby(
    search_query     TEXT,
    user_lat         DOUBLE PRECISION,
    user_lon         DOUBLE PRECISION,
    max_distance_km  DOUBLE PRECISION DEFAULT NULL,
    result_limit     INTEGER          DEFAULT 50
)
RETURNS TABLE (
    inventory_id  UUID,
    pharmacy_id   UUID,
    pharmacy_name TEXT,
    sub_city      TEXT,
    woreda        TEXT,
    phone         TEXT,
    latitude      DOUBLE PRECISION,
    longitude     DOUBLE PRECISION,
    brand_name    TEXT,
    generic_name  TEXT,
    category      TEXT,
    manufacturer  TEXT,
    stock_quantity INTEGER,
    price_etb    NUMERIC,
    batch_number TEXT,
    expiry_date  DATE,
    distance_km  DOUBLE PRECISION
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
    WITH base AS (
        SELECT
            pi.id              AS inventory_id,
            p.id               AS pharmacy_id,
            p.name             AS pharmacy_name,
            p.sub_city,
            p.woreda,
            p.phone,
            p.latitude,
            p.longitude,
            m.brand_name,
            m.generic_name,
            m.category,
            m.manufacturer,
            pi.stock_quantity,
            pi.price_etb,
            pi.batch_number,
            pi.expiry_date,
            -- Haversine great-circle distance, km
            (6371 * acos(
                LEAST(1.0, GREATEST(-1.0,
                    cos(radians(user_lat)) * cos(radians(p.latitude)) *
                    cos(radians(p.longitude) - radians(user_lon)) +
                    sin(radians(user_lat)) * sin(radians(p.latitude))
                ))
            )) AS distance_km
        FROM public.pharmacy_inventory pi
        JOIN public.medicines  m ON m.id = pi.medicine_id
        JOIN public.pharmacies p ON p.id = pi.pharmacy_id
        WHERE
            p.is_verified   = TRUE
            AND pi.is_available = TRUE
            AND pi.stock_quantity > 0
            AND p.latitude  IS NOT NULL
            AND p.longitude IS NOT NULL
            -- Case-insensitive substring match on brand or generic name.
            AND (
                m.brand_name   ILIKE '%' || search_query || '%'
                OR m.generic_name ILIKE '%' || search_query || '%'
            )
    )
    SELECT *
    FROM base
    WHERE max_distance_km IS NULL OR distance_km <= max_distance_km
    ORDER BY distance_km ASC
    LIMIT LEAST(GREATEST(result_limit, 1), 100);
$$;

COMMENT ON FUNCTION public.search_medicines_nearby IS
    'Consumer search: returns verified pharmacies with available stock for a given medicine, sorted by distance (Haversine).';

-- Grant execute to the public/anon role so the consumer app can call it
-- via the Supabase anon key.
GRANT EXECUTE ON FUNCTION public.search_medicines_nearby(TEXT, DOUBLE PRECISION, DOUBLE PRECISION, DOUBLE PRECISION, INTEGER)
    TO anon, authenticated;


-- ---------------------------------------------------------------------------
-- 6. SEED DATA (LOCAL DEV)
-- ---------------------------------------------------------------------------
-- Sample medicines
INSERT INTO public.medicines (brand_name, generic_name, category, manufacturer) VALUES
    ('Paracetamol 500mg', 'Acetaminophen',   'Analgesic',   'Cadila Pharmaceuticals'),
    ('Amoxil 500mg',      'Amoxicillin',     'Antibiotic',  'GSK'),
    ('Coartem',           'Artemether/Lumefantrine', 'Antimalarial', 'Novartis'),
    ('Metformin 500mg',   'Metformin HCl',   'Antidiabetic','Merck'),
    ('Omeprazole 20mg',   'Omeprazole',      'Antacid',     'Dr. Reddys'),
    ('ORS Sachet',        'Oral Rehydration Salts', 'Rehydration', 'FHC'),
    ('Iron + Folic Acid', 'Ferrous Sulfate + Folic Acid', 'Supplement', 'Cadila')
ON CONFLICT DO NOTHING;

-- Sample verified pharmacy around Bole, Addis Ababa (9.0054° N, 38.7636° E)
-- NOTE: replace owner_id with a real auth.users UUID before running.
-- INSERT INTO public.pharmacies (name, owner_id, phone, sub_city, woreda, latitude, longitude, is_verified)
-- VALUES ('Bole Pharmacy', '<AUTH-USER-UUID>', '+251911223344', 'Bole', 'Woreda 03', 9.0054, 38.7636, TRUE)
-- ON CONFLICT DO NOTHING;


-- =============================================================================
-- END OF SCHEMA
-- =============================================================================
